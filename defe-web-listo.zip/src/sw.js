/**
 * sw.js — el service worker de la app.
 *
 * Hace dos cosas: guardar la app para que abra sin señal, y recibir los
 * avisos push aunque la app esté cerrada.
 *
 * Para que Vite lo use, en vite.config.js: VitePWA({ strategies: "injectManifest",
 * srcDir: "src", filename: "sw.js", ... })
 */

import { precacheAndRoute } from "workbox-precaching";

precacheAndRoute(self.__WB_MANIFEST);

self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));

/* ------------------------------ el aviso ------------------------------ */

self.addEventListener("push", (evento) => {
  let aviso = { titulo: "El Defe", cuerpo: "", url: "/" };
  try {
    aviso = { ...aviso, ...evento.data.json() };
  } catch {
    aviso.cuerpo = evento.data?.text() || "";
  }

  evento.waitUntil(
    self.registration.showNotification(aviso.titulo, {
      body: aviso.cuerpo,
      icon: "/icono-192.png",
      badge: "/icono-192.png",
      // Un aviso del mismo tipo reemplaza al anterior en vez de apilarse:
      // si el horario cambia dos veces, la familia ve el último, no los dos.
      tag: aviso.tipo || "defe",
      renotify: true,
      data: { url: aviso.url || "/" },
      vibrate: [80, 40, 80],
    })
  );
});

/* Al tocar el aviso: si la app ya está abierta, la trae al frente en la
   sección correspondiente; si no, la abre ahí directamente. */
self.addEventListener("notificationclick", (evento) => {
  evento.notification.close();
  const destino = evento.notification.data?.url || "/";

  evento.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((ventanas) => {
      for (const v of ventanas) {
        if ("focus" in v) {
          v.navigate?.(destino);
          return v.focus();
        }
      }
      return self.clients.openWindow(destino);
    })
  );
});

/* Si el navegador rota la suscripción, hay que volver a guardarla.
   La app lo detecta al abrir y la registra de nuevo. */
self.addEventListener("pushsubscriptionchange", (evento) => {
  evento.waitUntil(
    self.clients.matchAll().then((cs) => cs.forEach((c) => c.postMessage({ tipo: "resuscribir" })))
  );
});
