/**
 * hooks.js — el puente entre las pantallas y los datos.
 *
 * Cada hook devuelve siempre algo usable, aunque la base no esté configurada
 * o no haya señal. Ninguna pantalla tiene que saber de dónde vienen los datos.
 */

import { useState, useEffect, useCallback } from "react";
import { hayBase, sesion, perfil, tienda, pedidos, contenidos, ligas } from "./datos.js";
import { LIGAS_URL } from "./config.js";

/* ============================== SESIÓN ============================== */

export function useSesion() {
  const [usuario, setUsuario] = useState(null);
  const [cargando, setCargando] = useState(hayBase);

  useEffect(() => {
    if (!hayBase) return;
    sesion.actual().then((p) => { setUsuario(p); setCargando(false); });
    return sesion.alCambiar(setUsuario);
  }, []);

  const entrar = useCallback(async (email, clave) => {
    const { perfil: p, error } = await sesion.entrar(email, clave);
    if (!error) setUsuario(p);
    return error;
  }, []);

  const registrarse = useCallback(async (email, clave, nombre) => {
    const { error } = await sesion.registrarse(email, clave, nombre);
    return error;
  }, []);

  const salir = useCallback(async () => {
    await sesion.salir();
    setUsuario(null);
  }, []);

  /* Favoritos y notificaciones: si hay sesión van al perfil; si no, quedan
     en el teléfono, así una familia puede usar la app sin crear cuenta. */
  const guardarPreferencias = useCallback(async (cambios) => {
    if (usuario?.id) {
      await perfil.guardarPreferencias(usuario.id, { ...usuario, ...cambios });
      setUsuario({ ...usuario, ...cambios });
    } else {
      try { await window.storage?.set("defe:prefs", JSON.stringify(cambios)); } catch {}
    }
  }, [usuario]);

  return { usuario, admin: Boolean(usuario?.admin), cargando, entrar, registrarse, salir, guardarPreferencias };
}

/* ============================== LIGAS ============================== */

export function useLigas() {
  const [datos, setDatos] = useState(null);
  const [estado, setEstado] = useState({ cargando: true, desdeCache: false });

  const recargar = useCallback(async () => {
    setEstado((e) => ({ ...e, cargando: true }));
    const { datos: d, desdeCache } = await ligas(LIGAS_URL);
    if (d) setDatos(d);
    setEstado({ cargando: false, desdeCache });
  }, []);

  useEffect(() => { recargar(); }, [recargar]);

  const porId = useCallback((id) => datos?.ligas?.find((l) => l.id === id) || null, [datos]);

  /* El próximo compromiso del club, mirando las cuatro ligas juntas. */
  const proximo = useCallback((favoritos = []) => {
    if (!datos) return null;
    const hoy = new Date().toISOString().slice(0, 10);
    const todos = datos.ligas.flatMap((l) =>
      (l.encuentros || l.partidos || [])
        .filter((p) => p.fecha >= hoy && p.gf == null)
        .map((p) => ({ ...p, liga: l.id, ligaNombre: l.nombre }))
    );
    const mios = favoritos.length
      ? todos.filter((p) => favoritos.includes(p.categoria) || favoritos.includes(p.liga))
      : todos;
    return (mios.length ? mios : todos).sort((a, b) => a.fecha.localeCompare(b.fecha))[0] || null;
  }, [datos]);

  return { datos, ...estado, recargar, porId, proximo, actualizado: datos?.actualizado, manual: datos?.manual };
}

/* ============================== TIENDA ============================== */

export function useCatalogo({ admin = false } = {}) {
  const [productos, setProductos] = useState([]);
  const [config, setConfig] = useState(null);
  const [cargando, setCargando] = useState(hayBase);

  const recargar = useCallback(async () => {
    if (!hayBase) return setCargando(false);
    const [{ datos }, cfg] = await Promise.all([
      tienda.catalogo({ soloVisibles: !admin }),
      tienda.configuracion(),
    ]);
    if (datos) setProductos(datos);
    if (cfg) setConfig(cfg);
    setCargando(false);
  }, [admin]);

  useEffect(() => { recargar(); }, [recargar]);

  const guardarProducto = useCallback(async (p) => {
    const { error } = await tienda.guardarProducto(p);
    if (!error) await recargar();
    return error;
  }, [recargar]);

  const guardarStock = useCallback(async (productoId, stock) => {
    const { error } = await tienda.guardarStock(productoId, stock);
    if (!error) await recargar();
    return error;
  }, [recargar]);

  const guardarConfig = useCallback(async (valor) => {
    await tienda.guardarConfiguracion(valor);
    setConfig(valor);
  }, []);

  return { productos, config, cargando, recargar, guardarProducto, guardarStock, guardarConfig };
}

/* ============================== PEDIDOS ============================== */

export function usePedidos({ admin = false, perfilId = null } = {}) {
  const [activos, setActivos] = useState([]);
  const [historial, setHistorial] = useState([]);
  const [cargando, setCargando] = useState(hayBase);

  const recargar = useCallback(async () => {
    if (!hayBase) return setCargando(false);
    if (admin) {
      const [a, h] = await Promise.all([pedidos.listar(), pedidos.listar({ historial: true })]);
      setActivos(a.datos || []);
      setHistorial(h.datos || []);
    } else if (perfilId) {
      const { datos } = await pedidos.mios(perfilId);
      const cerrados = ["entregado", "cancelado"];
      setActivos((datos || []).filter((p) => !cerrados.includes(p.estado)));
      setHistorial((datos || []).filter((p) => cerrados.includes(p.estado)));
    }
    setCargando(false);
  }, [admin, perfilId]);

  useEffect(() => { recargar(); }, [recargar]);

  /* Gestión se entera al toque cuando entra un pedido nuevo. */
  useEffect(() => {
    if (!admin) return;
    return pedidos.escuchar(() => recargar());
  }, [admin, recargar]);

  const crear = useCallback(async (datos) => {
    const { datos: pedido, error } = await pedidos.crear({ ...datos, perfilId });
    if (!error) await recargar();
    return { pedido, error };
  }, [perfilId, recargar]);

  const cambiarEstado = useCallback(async (id, estado) => {
    // Se refleja enseguida en pantalla; si la base falla, recargar lo corrige.
    setActivos((prev) => prev.map((p) => (p.id === id ? { ...p, estado } : p)));
    const { error } = await pedidos.cambiarEstado(id, estado);
    await recargar();
    return error;
  }, [recargar]);

  const cuenta = useCallback(
    (estado) => activos.filter((p) => p.estado === estado).length,
    [activos]
  );

  return { activos, historial, cargando, recargar, crear, cambiarEstado, cuenta };
}

/* ============================ CONTENIDOS ============================ */

export function useContenidos() {
  const [datos, setDatos] = useState({ planteles: [], goleadores: [], destacado: null, galeria: [], novedades: [] });
  const [cargando, setCargando] = useState(hayBase);

  const recargar = useCallback(async () => {
    if (!hayBase) return setCargando(false);
    const [pl, go, de, ga, no] = await Promise.all([
      contenidos.planteles(), contenidos.goleadores(), contenidos.jugadorDeLaFecha(),
      contenidos.galeria(), contenidos.novedades(),
    ]);
    setDatos({
      planteles: pl.datos || [], goleadores: go.datos || [], destacado: de || null,
      galeria: ga.datos || [], novedades: no.datos || [],
    });
    setCargando(false);
  }, []);

  useEffect(() => { recargar(); }, [recargar]);

  return { ...datos, cargando, recargar };
}

/* ========================= CARRITO (local) ========================= */
/* No necesita base: vive en el teléfono hasta que se confirma el pedido. */

export function useCarrito() {
  const [items, setItems] = useState([]);

  const agregar = useCallback((producto, talle) => {
    setItems((prev) => {
      const key = producto.id + "-" + talle;
      if (prev.find((i) => i.key === key)) {
        return prev.map((i) => (i.key === key ? { ...i, cant: i.cant + 1 } : i));
      }
      return [...prev, {
        key, productoId: producto.id, nombre: producto.nombre,
        precio: producto.precio, talle, cant: 1,
      }];
    });
  }, []);

  const cambiar = useCallback((key, delta) => {
    setItems((prev) =>
      prev.map((i) => (i.key === key ? { ...i, cant: i.cant + delta } : i)).filter((i) => i.cant > 0)
    );
  }, []);

  const vaciar = useCallback(() => setItems([]), []);
  const total = items.reduce((s, i) => s + (i.precio || 0) * i.cant, 0);
  const unidades = items.reduce((s, i) => s + i.cant, 0);
  const aConfirmar = items.some((i) => !i.precio);

  return { items, agregar, cambiar, vaciar, total, unidades, aConfirmar };
}
