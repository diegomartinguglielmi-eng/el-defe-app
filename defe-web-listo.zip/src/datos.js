/**
 * datos.js — todo lo que la app necesita pedirle o escribirle a la base.
 *
 *   npm install @supabase/supabase-js
 *
 * Las dos variables van en el .env del proyecto. La clave "anon" es pública
 * a propósito: lo que protege los datos son las políticas del esquema, no
 * esconder la clave.
 *
 *   VITE_SUPABASE_URL=https://xxxxx.supabase.co
 *   VITE_SUPABASE_ANON_KEY=eyJhbGci...
 *
 * Si no están configuradas, todo sigue funcionando contra el almacenamiento
 * del teléfono: la app arranca igual y no se rompe nada.
 */

import { createClient } from "@supabase/supabase-js";

const URL = import.meta.env?.VITE_SUPABASE_URL;
const CLAVE = import.meta.env?.VITE_SUPABASE_ANON_KEY;

export const hayBase = Boolean(URL && CLAVE);
export const sb = hayBase ? createClient(URL, CLAVE) : null;

/* Cualquier consulta devuelve { datos, error } y nunca tira una excepción:
   si la base no responde, la pantalla muestra lo último que tenía. */
async function pedir(consulta) {
  if (!hayBase) return { datos: null, error: "sin base configurada" };
  try {
    const { data, error } = await consulta;
    if (error) throw error;
    return { datos: data, error: null };
  } catch (err) {
    console.error("[datos]", err.message);
    return { datos: null, error: err.message };
  }
}

/* ============================== SESIÓN ============================== */

export const sesion = {
  async actual() {
    if (!hayBase) return null;
    const { data } = await sb.auth.getSession();
    if (!data.session) return null;
    return perfil.mio(data.session.user);
  },

  async registrarse(email, clave, nombre) {
    const { data, error } = await sb.auth.signUp({
      email, password: clave, options: { data: { nombre } },
    });
    if (error) return { error: traducir(error.message) };
    return { usuario: data.user };
  },

  async entrar(email, clave) {
    const { data, error } = await sb.auth.signInWithPassword({ email, password: clave });
    if (error) return { error: traducir(error.message) };
    return { perfil: await perfil.mio(data.user) };
  },

  async salir() {
    await sb?.auth.signOut();
  },

  async recuperar(email) {
    const { error } = await sb.auth.resetPasswordForEmail(email);
    return { error: error ? traducir(error.message) : null };
  },

  /* Avisa cuando la sesión cambia (entrar, salir, expirar). */
  alCambiar(callback) {
    if (!hayBase) return () => {};
    const { data } = sb.auth.onAuthStateChange(async (_evento, s) => {
      callback(s ? await perfil.mio(s.user) : null);
    });
    return () => data.subscription.unsubscribe();
  },
};

function traducir(mensaje) {
  if (/Invalid login/i.test(mensaje)) return "Email o contraseña incorrectos.";
  if (/already registered/i.test(mensaje)) return "Ese email ya tiene cuenta.";
  if (/Password should be/i.test(mensaje)) return "La contraseña necesita al menos 6 caracteres.";
  if (/Email not confirmed/i.test(mensaje)) return "Falta confirmar el email; revisá tu casilla.";
  return mensaje;
}

/* ============================== PERFIL ============================== */

export const perfil = {
  async mio(usuario) {
    const { datos } = await pedir(sb.from("perfiles").select("*").eq("id", usuario.id).single());
    return datos ? { ...datos, admin: datos.rol === "dirigente" } : { id: usuario.id, email: usuario.email, admin: false };
  },

  async guardarPreferencias(id, { favoritos, notificaciones, nombre, telefono }) {
    return pedir(sb.from("perfiles").update({ favoritos, notificaciones, nombre, telefono }).eq("id", id));
  },
};

/* ============================== TIENDA ============================== */

export const tienda = {
  /* Catálogo con el stock ya adentro de cada producto. */
  async catalogo({ soloVisibles = true } = {}) {
    let q = sb.from("productos").select("*, stock(talle, cantidad)").order("creado", { ascending: false });
    if (soloVisibles) q = q.eq("visible", true);
    const { datos, error } = await pedir(q);
    if (error) return { datos: null, error };
    return {
      datos: datos.map((p) => ({
        ...p,
        stock: p.controla_stock
          ? Object.fromEntries(p.stock.map((s) => [s.talle, s.cantidad]))
          : null,
      })),
      error: null,
    };
  },

  async guardarProducto(p) {
    const fila = {
      nombre: p.nombre, rubro: p.rubro, precio: p.precio, talles: p.talles,
      nota: p.nota, visible: p.visible, destacado: p.destacado,
      controla_stock: Boolean(p.stock),
    };
    const consulta = p.id
      ? sb.from("productos").update(fila).eq("id", p.id).select().single()
      : sb.from("productos").insert(fila).select().single();
    return pedir(consulta);
  },

  async guardarStock(productoId, stock) {
    if (!stock) {
      await pedir(sb.from("productos").update({ controla_stock: false }).eq("id", productoId));
      return pedir(sb.from("stock").delete().eq("producto_id", productoId));
    }
    await pedir(sb.from("productos").update({ controla_stock: true }).eq("id", productoId));
    const filas = Object.entries(stock).map(([talle, cantidad]) => ({
      producto_id: productoId, talle, cantidad: Number(cantidad) || 0,
    }));
    return pedir(sb.from("stock").upsert(filas, { onConflict: "producto_id,talle" }));
  },

  async configuracion() {
    const { datos } = await pedir(sb.from("config").select("valor").eq("clave", "tienda").single());
    return datos?.valor || null;
  },

  async guardarConfiguracion(valor) {
    return pedir(sb.from("config").upsert({ clave: "tienda", valor, actualizado: new Date() }));
  },
};

/* ============================== PEDIDOS ============================== */

export const pedidos = {
  /* Crea el pedido y sus ítems. El número y el descuento de stock los
     resuelve la base, así que no hay dos pedidos con el mismo número
     aunque dos personas confirmen al mismo tiempo. */
  async crear({ perfilId, nombre, telefono, categoria, retiro, nota, total, items }) {
    const { datos: pedido, error } = await pedir(
      sb.from("pedidos").insert({
        perfil_id: perfilId || null, nombre, telefono, categoria, retiro, nota, total,
      }).select().single()
    );
    if (error) return { datos: null, error };

    const { error: errorItems } = await pedir(
      sb.from("pedido_items").insert(items.map((i) => ({
        pedido_id: pedido.id, producto_id: i.productoId || null,
        nombre: i.nombre, talle: i.talle, cantidad: i.cant, precio: i.precio,
      })))
    );
    if (errorItems) return { datos: pedido, error: errorItems };
    return { datos: pedido, error: null };
  },

  async listar({ historial = false } = {}) {
    const cerrados = ["entregado", "cancelado"];
    let q = sb.from("pedidos").select("*, pedido_items(*)").order("creado", { ascending: false });
    q = historial ? q.in("estado", cerrados) : q.not("estado", "in", `(${cerrados.join(",")})`);
    return pedir(q);
  },

  async mios(perfilId) {
    return pedir(
      sb.from("pedidos").select("*, pedido_items(*)").eq("perfil_id", perfilId).order("creado", { ascending: false })
    );
  },

  async cambiarEstado(id, estado) {
    return pedir(sb.from("pedidos").update({ estado }).eq("id", id).select().single());
  },

  /* El panel de Gestión se entera solo cuando entra o cambia un pedido. */
  escuchar(callback) {
    if (!hayBase) return () => {};
    const canal = sb.channel("pedidos")
      .on("postgres_changes", { event: "*", schema: "public", table: "pedidos" }, callback)
      .subscribe();
    return () => sb.removeChannel(canal);
  },
};

/* ============================ CONTENIDOS ============================ */

export const contenidos = {
  async planteles() {
    return pedir(
      sb.from("planteles")
        .select("*, jugadores(id, numero, nombre, puesto, goles)")
        .order("orden")
    );
  },

  async goleadores(limite = 10) {
    return pedir(
      sb.from("jugadores")
        .select("nombre, goles, numero, puesto, planteles(competencia, categoria)")
        .gt("goles", 0).order("goles", { ascending: false }).limit(limite)
    );
  },

  async jugadorDeLaFecha() {
    const { datos } = await pedir(
      sb.from("destacados").select("*").order("creado", { ascending: false }).limit(1).single()
    );
    return datos;
  },

  async galeria() {
    return pedir(sb.from("galeria").select("*").order("creado", { ascending: false }).limit(30));
  },

  async novedades() {
    return pedir(
      sb.from("novedades").select("*").eq("visible", true).order("creado", { ascending: false }).limit(20)
    );
  },

  async publicarNovedad(n) {
    return pedir(sb.from("novedades").insert(n).select().single());
  },

  async publicarFoto(f) {
    return pedir(sb.from("galeria").insert(f).select().single());
  },

  async definirJugadorDeLaFecha(d) {
    return pedir(sb.from("destacados").insert(d).select().single());
  },
};

/* ========================= CARGA MANUAL ========================= */
/* Horarios por categoría y partidos que la liga no publica. */

export const manual = {
  async listar(liga) {
    let q = sb.from("carga_manual").select("*").order("creado", { ascending: false });
    if (liga) q = q.eq("liga", liga);
    return pedir(q);
  },

  async guardarHorarios(liga, fecha, detalle) {
    return pedir(sb.from("carga_manual").upsert({
      tipo: "horarios", liga, referencia: String(fecha), datos: { detalle },
    }));
  },

  async guardarPartido(liga, partido) {
    return pedir(sb.from("carga_manual").insert({ tipo: "partido", liga, datos: partido }));
  },

  async borrar(id) {
    return pedir(sb.from("carga_manual").delete().eq("id", id));
  },
};

/* ===================== LIGAS (lo que sincroniza GitHub) ===================== */
/* Esto no pasa por la base: sale del datos.json que publica GitHub Pages.
   Se guarda una copia en el teléfono para que la app abra sin señal. */

const CACHE = "defe:ligas";

export async function ligas(urlDatos) {
  try {
    const r = await fetch(urlDatos, { cache: "no-cache" });
    const datos = await r.json();
    try { await window.storage?.set(CACHE, JSON.stringify(datos)); } catch {}
    return { datos, desdeCache: false };
  } catch {
    try {
      const guardado = await window.storage?.get(CACHE);
      if (guardado) return { datos: JSON.parse(guardado.value), desdeCache: true };
    } catch {}
    return { datos: null, desdeCache: false };
  }
}
