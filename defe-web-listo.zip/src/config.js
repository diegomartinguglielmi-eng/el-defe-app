/* Todo lo que cambia de un club a otro, o de un año a otro, vive acá. */

export const CLUB = {
  nombre: "Club Defensores de Santos Lugares",
  corto: "Defe",
  sede: "Ernesto Sábato 3162, Santos Lugares",
  instagram: "@dsl_futbol",
};

export const LIGAS_URL = import.meta.env.VITE_LIGAS_URL;

export const COLORES = {
  azul: "#2E3192", azulVivo: "#4B50C6", azulTinte: "#ECEDFB", oro: "#F2B705",
  tinta: "#101828", gris: "#69748A", linea: "#DFE5F0", fondo: "#F3F6FB",
  gana: "#12805C", pierde: "#C0392B", empata: "#8A94A6", whatsapp: "#25D366",
};
