/**
 * push.js — pedir permiso y registrar el teléfono para recibir avisos.
 *
 * Detalles del mundo real que resuelve este archivo:
 *  - En iPhone solo funciona si la app está instalada en la pantalla de inicio
 *    (iOS 16.4 o mayor). Desde Safari suelto, no hay push. Conviene decírselo
 *    a la persona en vez de dejar un botón que no hace nada.
 *  - El permiso se pide una sola vez: si lo rechazan, el navegador no lo vuelve
 *    a preguntar y hay que cambiarlo a mano en la configuración del sitio.
 */

import { sb, hayBase } from "./datos.js";

const CLAVE_PUBLICA = import.meta.env.VITE_VAPID_PUBLICA;

/* ¿Se puede, en este teléfono y en este momento? */
export function estadoPush() {
  const soportado = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
  const instalada = window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
  const esIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);

  if (!soportado) {
    return { puede: false, motivo: "Este navegador no permite avisos." };
  }
  if (esIOS && !instalada) {
    return {
      puede: false,
      motivo: "En iPhone hay que instalar la app primero: Compartir → Agregar a pantalla de inicio.",
    };
  }
  if (!CLAVE_PUBLICA || !hayBase) {
    return { puede: false, motivo: "Los avisos todavía no están configurados." };
  }
  return { puede: true, permiso: Notification.permission };
}

function aBytes(base64) {
  const relleno = "=".repeat((4 - (base64.length % 4)) % 4);
  const limpia = (base64 + relleno).replace(/-/g, "+").replace(/_/g, "/");
  const crudo = atob(limpia);
  return Uint8Array.from([...crudo].map((c) => c.charCodeAt(0)));
}

/* Pide permiso, se suscribe y guarda el teléfono en la base. */
export async function activarAvisos(perfilId) {
  const estado = estadoPush();
  if (!estado.puede) return { error: estado.motivo };

  const permiso = await Notification.requestPermission();
  if (permiso !== "granted") {
    return {
      error: permiso === "denied"
        ? "Los avisos están bloqueados. Se habilitan desde la configuración del navegador para este sitio."
        : "Quedó sin confirmar.",
    };
  }

  try {
    const registro = await navigator.serviceWorker.ready;
    const suscripcion =
      (await registro.pushManager.getSubscription()) ||
      (await registro.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: aBytes(CLAVE_PUBLICA),
      }));

    const datos = suscripcion.toJSON();
    const { error } = await sb.from("suscripciones").upsert(
      {
        perfil_id: perfilId || null,
        endpoint: datos.endpoint,
        p256dh: datos.keys.p256dh,
        auth: datos.keys.auth,
        dispositivo: navigator.userAgent.slice(0, 120),
        ultimo_uso: new Date(),
      },
      { onConflict: "endpoint" }
    );
    if (error) throw error;

    return { ok: true };
  } catch (err) {
    console.error("[push]", err);
    return { error: "No pudimos registrar este teléfono. Probá de nuevo más tarde." };
  }
}

export async function desactivarAvisos() {
  try {
    const registro = await navigator.serviceWorker.ready;
    const suscripcion = await registro.pushManager.getSubscription();
    if (!suscripcion) return { ok: true };
    await sb?.from("suscripciones").delete().eq("endpoint", suscripcion.endpoint);
    await suscripcion.unsubscribe();
    return { ok: true };
  } catch {
    return { error: "No pudimos dar de baja los avisos en este teléfono." };
  }
}

export async function estaSuscripto() {
  if (!("serviceWorker" in navigator)) return false;
  const registro = await navigator.serviceWorker.ready;
  return Boolean(await registro.pushManager.getSubscription());
}

/* Si el navegador rota la suscripción, el service worker avisa y se vuelve
   a registrar sola, sin molestar a la persona. */
export function escucharRenovacion(perfilId) {
  if (!("serviceWorker" in navigator)) return () => {};
  const manejar = (e) => { if (e.data?.tipo === "resuscribir") activarAvisos(perfilId); };
  navigator.serviceWorker.addEventListener("message", manejar);
  return () => navigator.serviceWorker.removeEventListener("message", manejar);
}
