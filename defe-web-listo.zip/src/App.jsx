import React, { useState, useEffect, createContext, useContext } from "react";
import { useSesion, useLigas, useCatalogo, usePedidos, useContenidos, useCarrito } from "./hooks.js";
import { manual as manualApi } from "./datos.js";
import { activarAvisos, desactivarAvisos, estadoPush, estaSuscripto, escucharRenovacion } from "./push.js";
import {
  Home, CalendarDays, ShoppingBag, Newspaper, Star, ChevronLeft, ChevronRight,
  MapPin, X, Plus, Minus, Check, RefreshCw, Pencil,
  CloudDownload, AlertCircle, Clock, Navigation, MessageCircle, Users, User, Bell,
} from "lucide-react";

/* ==================================================================
 *  DEFE FÚTBOL — Club Defensores de Santos Lugares
 *
 *  Los datos de FEFI son REALES (Torneo Anual 2026, Zona H, Clausura),
 *  leídos de https://fefi.com.ar/2026-torneo-anual-baby-futbol/h/
 *  El script sync-ligas.mjs regenera este bloque en datos.json.
 *
 *  LAMBA, Superliga y Argenliga todavía no tienen fuente conectada:
 *  se cargan a mano desde la pantalla de Datos.
 * ================================================================== */

const C = {
  azul: "#2E3192", azulVivo: "#4B50C6", azulTinte: "#ECEDFB", oro: "#F2B705",
  tinta: "#101828", gris: "#69748A", linea: "#DFE5F0", fondo: "#F3F6FB",
  gana: "#12805C", pierde: "#C0392B", empata: "#8A94A6",
};

const CLUB = "DEF. DE SANTOS LUGARES";
const SEDE_LOCAL = "Ernesto Sábato 3162, Santos Lugares";

/* Reemplazar por el número real de la tienda, en formato internacional
   sin espacios ni signos: 54 9 11 xxxx xxxx → 54911xxxxxxxx */
const TIENDA = { whatsapp: "5491100000000", instagram: "@tiendadsl" };

/* Google Maps abre igual con una dirección o con el nombre de una cancha. */
const comoLlegar = (destino) =>
  `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destino)}`;

const LIGAS = {
  fefi: {
    nombre: "FEFI", tono: "#1450C8", disciplina: "Baby fútbol", tipo: "fefi",
    torneo: "Clausura 2026 · Zona H",
    fuente: "https://fefi.com.ar/2026-torneo-anual-baby-futbol/h/",
    conectada: true, actualizado: "2026-09-08T07:10:00",
    categorias: ["2013", "2014", "2015", "2016", "2017", "2018", "2019"],
  },
  superliga: {
    nombre: "Superliga", tono: "#7048C0", disciplina: "Futsal", tipo: "simple",
    torneo: "Junior A · Torneo 2026",
    fuente: "https://www.futsalargentina.com.ar/fixture.php?cat=1_1",
    conectada: true, actualizado: "2026-09-08T07:15:00", categorias: ["Junior A"],
  },
  lamba: {
    nombre: "LAAMBA", tono: "#0B7285", disciplina: "Futsal", tipo: "simple",
    torneo: "M - Elite I · F - Ascenso I Zona B",
    fuente: "https://www.laamba.ar/torneoslaamba/masculino/m-elite-i/1ra/torneo/m-eliteiclausura/?db=2026",
    conectada: true, actualizado: "2026-09-08T07:20:00",
    categorias: ["1RA", "3RA", "4TA", "5TA", "6TA", "7MA", "8VA", "FEM 1RA"],
  },
  argenliga: {
    nombre: "Argenliga", tono: "#C0392B", disciplina: "Futsal", tipo: "simple",
    torneo: "Argenliga A · Zona 1", fuente: "https://www.sofascore.com/es-la/futsal/team/defensores-de-santos-lugares/1214864",
    conectada: false, actualizado: null, categorias: [],
    pendiente: "Equipo ya identificado (Sofascore 1214864). Entra en la próxima sincronización: 3° con 10 puntos.",
  },
};

/* Superliga Futsal — Junior A. Datos reales del sitio de la liga. */
const SUPERLIGA = {
  partidos: [
    { nro: 4, fecha: "2026-08-31", hora: "23:00", rival: "All Boys (J)", local: false, sede: "CEDEM N° 1", gf: 3, gc: 0 },
    { nro: 5, fecha: "2026-09-07", hora: null, rival: null, local: null, sede: null, gf: null, gc: null },
  ],
  tablas: {
    "General": [
      ["Pasaje Futsal", 4, 3, 1, 0, 10], ["El Talar", 4, 3, 1, 0, 10], ["Ferro", 3, 3, 0, 0, 9],
      ["Defensores Santos Lugares", 3, 3, 0, 0, 9], ["Atlanta (J)", 4, 2, 1, 1, 7], ["Cultural (J)", 4, 2, 1, 1, 7],
      ["Ituzaingo (J)", 4, 2, 0, 2, 6], ["Deportivo Luro (J)", 4, 1, 0, 3, 3], ["Villa Rosales", 4, 1, 0, 3, 3],
      ["Platense", 3, 1, 0, 2, 3], ["All Boys (J)", 4, 1, 0, 3, 3], ["Hebraica (J)", 4, 0, 0, 4, 0],
      ["Club Mitre (J)", 3, 0, 0, 3, 0],
    ].map(([equipo, pj, g, e, p, pts]) => ({ equipo, pj, g, e, p, pts })),
  },
};

/* LAAMBA — Masculino, M - Elite I. El club juega de 1ra a 8va. */
const LAAMBA = {
  partidos: [],
  tablas: {
    "1RA": [
      ["Defensores de SL", 6, 5, 0, 1, 15, 9], ["Club Pampero", 6, 4, 0, 2, 12, 6], ["Amistad", 5, 3, 1, 1, 10, -2],
      ["Mariano Moreno", 4, 3, 0, 1, 9, 12], ["Cantera Zona Norte", 6, 3, 0, 3, 9, 9], ["Parque Patricios", 4, 3, 0, 1, 9, 6],
      ["El Lucero Futsal", 5, 3, 0, 2, 9, 1], ["CEDIMA", 4, 2, 1, 1, 7, 4], ["California", 5, 2, 1, 2, 7, -4],
      ["Club Aliados", 6, 2, 0, 4, 6, -7],
    ].map(([equipo, pj, g, e, p, pts, dg]) => ({ equipo, pj, g, e, p, pts, dg })),
  },
};

/* Direcciones publicadas por FEFI para la zona */
const SEDES = {
  "ATLETICO LUGANO": "José Ignacio Rucci 4170, CABA",
  "ESTRADA 2": "Tejedor 867, CABA",
  'C. S. D. ARGENTINO "1"': "Albariño 2253, CABA",
  "DEFENSORES DE HAEDO": "Defensa 941, Haedo",
  "CNEL. BRANDSEN": "Roque Simone 3951, La Tablada",
  "C. A. CENTENARIO S. M.": "Caseros 2849, San Andrés",
  "LAMADRID": "Desaguadero 3180, CABA",
  "BOYA - C. A. I.": "Boyacá 470, CABA",
  "EL TREBOL": "Gándara 2840, CABA",
  "GIMNASIA": "Joaquín V. González 1511, CABA",
  "A DOS TOQUES F. C.": "Paso 399, Avellaneda",
  "FRANJA DE ORO 1": "Av. Amancio Alcorta 3960, CABA",
  "ALVEAR": "José E. Rodó 4190, CABA",
  "NOLTING": "Alianza 350, Ciudadela",
  "EL FORTIN DE BELGRANO": "Cramer 3249, CABA",
};

/* Encuentros del Defe — Clausura 2026, Zona H.
   marc: goles por categoría [Defe, rival]. "GP" = ganó los puntos. */
const ENCUENTROS_FEFI = [
  { nro: 1, fecha: "2026-08-08", rival: "ATLETICO LUGANO", local: false, estado: "verificado", pts: [18, 9],
    marc: { "2019": [5, 2], "2013": "GP", "2018": [4, 1], "2014": [2, 0], "2017": [2, 6], "2016": [1, 1], "2015": [7, 0] } },
  { nro: 2, fecha: "2026-08-15", rival: "ESTRADA 2", local: true, estado: "verificado", pts: [18, 10],
    marc: { "2019": [4, 1], "2013": [2, 0], "2018": [11, 0], "2014": [2, 1], "2017": [1, 1], "2016": [1, 3], "2015": [10, 5] } },
  { nro: 3, fecha: "2026-08-22", rival: 'C. S. D. ARGENTINO "1"', local: false, estado: "verificado", pts: [14, 14],
    marc: { "2019": [2, 2], "2013": [1, 4], "2018": [1, 1], "2014": [2, 2], "2017": [1, 2], "2016": [2, 0], "2015": [5, 1] } },
  { nro: 4, fecha: "2026-08-29", rival: "DEFENSORES DE HAEDO", local: true, estado: "verificado", pts: [16, 12],
    marc: { "2019": [2, 0], "2013": [0, 2], "2018": [2, 0], "2014": [2, 2], "2017": [6, 1], "2016": [2, 5], "2015": [4, 1] } },
  { nro: 5, fecha: "2026-09-05", rival: "CNEL. BRANDSEN", local: false, estado: "previo", pts: [18, 10],
    marc: { "2019": [9, 0], "2013": [4, 2], "2018": [3, 1], "2014": [2, 7], "2017": [4, 1], "2016": [0, 0], "2015": [5, 3] } },
  { nro: 6, fecha: "2026-09-12", rival: "C. A. CENTENARIO S. M.", local: true },
  { nro: 7, fecha: "2026-09-19", rival: "LAMADRID", local: false },
  { nro: 8, fecha: "2026-09-26", rival: "BOYA - C. A. I.", local: true },
  { nro: 9, fecha: "2026-10-03", rival: "EL TREBOL", local: false },
  { nro: 10, fecha: "2026-10-10", rival: "GIMNASIA", local: true },
  { nro: 11, fecha: "2026-10-17", rival: "A DOS TOQUES F. C.", local: false },
  { nro: 12, fecha: "2026-10-24", rival: "FRANJA DE ORO 1", local: true },
  { nro: 13, fecha: "2026-10-31", rival: "ALVEAR", local: false },
  { nro: 14, fecha: "2026-11-07", rival: "NOLTING", local: true },
  { nro: 15, fecha: "2026-11-14", rival: "EL FORTIN DE BELGRANO", local: false },
].map((e) => ({ ...e, sede: e.local ? SEDE_LOCAL : SEDES[e.rival] || "A confirmar", jugado: !!e.marc }));

/* Horarios por categoría que publica el club (FEFI no los publica).
   Fecha 6 vs Centenario de San Andrés, sábado 12/09 en Ernesto Sábato 3162. */
const HORARIOS_FEFI = {
  6: {
    entrada: 7000,
    horas: { "2019": "14:30", "2013": "15:15", "2018": "16:10", "2014": "16:55", "2017": "17:50", "2016": "18:45", "2015": "19:40" },
  },
};

/* Tablas del Clausura: [equipo, PJ, G, E, P, Pts]. Ganado 3, empatado 2, perdido 1. */
const T = {
  general: [
    [CLUB, 35, 21, 7, 7, 84], ["NOLTING", 35, 21, 5, 9, 82], ['C. S. D. ARGENTINO "1"', 35, 18, 4, 13, 75],
    ["ALVEAR", 31, 16, 5, 10, 68], ["LAMADRID", 32, 14, 4, 14, 64], ["CNEL. BRANDSEN", 35, 11, 7, 16, 63],
    ["FRANJA DE ORO 1", 28, 15, 4, 9, 62], ["ESTRADA 2", 35, 10, 2, 23, 57], ["C. A. CENTENARIO S. M.", 28, 12, 3, 13, 55],
    ["BOYA - C. A. I.", 21, 13, 3, 5, 50], ["DEFENSORES DE HAEDO", 24, 10, 3, 11, 47], ["EL FORTIN DE BELGRANO", 25, 11, 3, 6, 45],
    ["EL TREBOL", 21, 10, 1, 10, 42], ["GIMNASIA", 25, 6, 2, 17, 39], ["ATLETICO LUGANO", 25, 6, 2, 13, 35],
    ["A DOS TOQUES F. C.", 21, 4, 3, 14, 32]],
  "2019": [
    [CLUB, 5, 4, 1, 0, 14], ['C. S. D. ARGENTINO "1"', 5, 4, 1, 0, 14], ["NOLTING", 5, 4, 0, 1, 13],
    ["EL FORTIN DE BELGRANO", 4, 4, 0, 0, 12], ["GIMNASIA", 4, 3, 0, 1, 10], ["FRANJA DE ORO 1", 4, 3, 0, 1, 10],
    ["ALVEAR", 5, 1, 2, 2, 9], ["DEFENSORES DE HAEDO", 4, 2, 0, 2, 8], ["LAMADRID", 5, 1, 1, 3, 8],
    ["CNEL. BRANDSEN", 5, 1, 1, 2, 7], ["ATLETICO LUGANO", 4, 1, 0, 3, 6], ["C. A. CENTENARIO S. M.", 4, 1, 0, 3, 6],
    ["BOYA - C. A. I.", 3, 1, 0, 2, 5], ["EL TREBOL", 3, 1, 0, 2, 5], ["ESTRADA 2", 5, 0, 0, 5, 5],
    ["A DOS TOQUES F. C.", 3, 0, 0, 3, 3]],
  "2013": [
    ["NOLTING", 5, 3, 1, 1, 12], ["ALVEAR", 5, 2, 2, 1, 11], [CLUB, 5, 3, 0, 2, 11],
    ['C. S. D. ARGENTINO "1"', 5, 3, 0, 2, 11], ["CNEL. BRANDSEN", 5, 2, 2, 1, 11], ["C. A. CENTENARIO S. M.", 4, 3, 1, 0, 11],
    ["LAMADRID", 5, 2, 1, 2, 10], ["BOYA - C. A. I.", 3, 3, 0, 0, 9], ["ESTRADA 2", 5, 2, 0, 3, 9],
    ["FRANJA DE ORO 1", 4, 2, 0, 2, 8], ["EL TREBOL", 3, 2, 0, 1, 7], ["A DOS TOQUES F. C.", 3, 1, 1, 1, 6],
    ["DEFENSORES DE HAEDO", 4, 1, 0, 3, 6], ["GIMNASIA", 4, 0, 0, 4, 4], ["ATLETICO LUGANO", 4, 0, 0, 0, 0],
    ["EL FORTIN DE BELGRANO", 4, 0, 0, 0, 0]],
  "2018": [
    [CLUB, 5, 4, 1, 0, 14], ['C. S. D. ARGENTINO "1"', 5, 4, 1, 0, 14], ["LAMADRID", 5, 3, 1, 1, 12],
    ["FRANJA DE ORO 1", 4, 3, 1, 0, 11], ["ALVEAR", 5, 3, 0, 2, 11], ["NOLTING", 5, 2, 2, 1, 11],
    ["EL FORTIN DE BELGRANO", 4, 3, 1, 0, 11], ["GIMNASIA", 4, 2, 2, 0, 10], ["CNEL. BRANDSEN", 5, 1, 1, 3, 8],
    ["ATLETICO LUGANO", 4, 1, 1, 2, 7], ["BOYA - C. A. I.", 3, 0, 2, 1, 5], ["ESTRADA 2", 5, 0, 0, 5, 5],
    ["DEFENSORES DE HAEDO", 4, 0, 1, 3, 5], ["C. A. CENTENARIO S. M.", 4, 0, 1, 3, 5], ["A DOS TOQUES F. C.", 3, 0, 1, 2, 4],
    ["EL TREBOL", 3, 0, 0, 3, 3]],
  "2014": [
    ["NOLTING", 5, 4, 1, 0, 14], ["CNEL. BRANDSEN", 5, 3, 1, 1, 12], ["FRANJA DE ORO 1", 4, 3, 1, 0, 11],
    [CLUB, 5, 2, 2, 1, 11], ["ESTRADA 2", 5, 3, 0, 2, 11], ["ALVEAR", 4, 3, 0, 1, 10],
    ["EL TREBOL", 3, 3, 0, 0, 9], ['C. S. D. ARGENTINO "1"', 5, 1, 1, 3, 8], ["BOYA - C. A. I.", 3, 2, 0, 1, 7],
    ["A DOS TOQUES F. C.", 3, 2, 0, 1, 7], ["LAMADRID", 5, 1, 0, 4, 7], ["C. A. CENTENARIO S. M.", 4, 1, 0, 3, 6],
    ["DEFENSORES DE HAEDO", 3, 0, 2, 1, 5], ["EL FORTIN DE BELGRANO", 4, 1, 0, 2, 5], ["GIMNASIA", 4, 0, 0, 4, 4],
    ["ATLETICO LUGANO", 4, 0, 0, 4, 4]],
  "2017": [
    ["LAMADRID", 4, 4, 0, 0, 12], [CLUB, 5, 2, 1, 2, 10], ["ESTRADA 2", 5, 2, 1, 2, 10],
    ['C. S. D. ARGENTINO "1"', 5, 2, 1, 2, 10], ["ALVEAR", 4, 2, 1, 1, 9], ["ATLETICO LUGANO", 3, 3, 0, 0, 9],
    ["EL FORTIN DE BELGRANO", 3, 3, 0, 0, 9], ["FRANJA DE ORO 1", 4, 2, 0, 2, 8], ["NOLTING", 5, 1, 1, 3, 8],
    ["BOYA - C. A. I.", 3, 2, 0, 1, 7], ["DEFENSORES DE HAEDO", 3, 2, 0, 1, 7], ["CNEL. BRANDSEN", 5, 1, 0, 4, 7],
    ["C. A. CENTENARIO S. M.", 4, 1, 1, 2, 7], ["EL TREBOL", 3, 1, 0, 2, 5], ["GIMNASIA", 3, 0, 0, 3, 3],
    ["A DOS TOQUES F. C.", 3, 0, 0, 3, 3]],
  "2016": [
    ["C. A. CENTENARIO S. M.", 4, 4, 0, 0, 12], ["NOLTING", 5, 3, 0, 2, 11], ["LAMADRID", 4, 3, 1, 0, 11],
    ["BOYA - C. A. I.", 3, 3, 0, 0, 9], [CLUB, 5, 1, 2, 2, 9], ["ESTRADA 2", 5, 2, 0, 3, 9],
    ['C. S. D. ARGENTINO "1"', 5, 2, 0, 3, 9], ["DEFENSORES DE HAEDO", 3, 3, 0, 0, 9], ["ALVEAR", 4, 2, 0, 2, 8],
    ["CNEL. BRANDSEN", 5, 1, 1, 3, 8], ["FRANJA DE ORO 1", 4, 1, 1, 2, 7], ["ATLETICO LUGANO", 3, 1, 1, 1, 6],
    ["GIMNASIA", 3, 1, 0, 2, 5], ["EL TREBOL", 3, 0, 1, 2, 4], ["EL FORTIN DE BELGRANO", 3, 0, 1, 2, 4],
    ["A DOS TOQUES F. C.", 3, 0, 0, 3, 3]],
  "2015": [
    [CLUB, 5, 5, 0, 0, 15], ["NOLTING", 5, 4, 0, 1, 13], ["ALVEAR", 4, 3, 0, 1, 10],
    ["CNEL. BRANDSEN", 5, 2, 1, 2, 10], ["EL TREBOL", 3, 3, 0, 0, 9], ['C. S. D. ARGENTINO "1"', 5, 2, 0, 3, 9],
    ["BOYA - C. A. I.", 3, 2, 1, 0, 8], ["ESTRADA 2", 5, 1, 1, 3, 8], ["C. A. CENTENARIO S. M.", 4, 2, 0, 2, 8],
    ["FRANJA DE ORO 1", 4, 1, 1, 2, 7], ["DEFENSORES DE HAEDO", 3, 2, 0, 1, 7], ["A DOS TOQUES F. C.", 3, 1, 1, 1, 6],
    ["LAMADRID", 4, 0, 0, 4, 4], ["EL FORTIN DE BELGRANO", 3, 0, 1, 2, 4], ["GIMNASIA", 3, 0, 0, 3, 3],
    ["ATLETICO LUGANO", 3, 0, 0, 3, 3]],
};

const TABLAS = Object.fromEntries(
  Object.entries(T).map(([k, filas]) => [k, filas.map(([equipo, pj, g, e, p, pts]) => ({ equipo, pj, g, e, p, pts }))])
);

const PRODUCTOS = [
  { id: "t1", nombre: "Camiseta titular 2026", rubro: "Camisetas", precio: 42000, talles: ["4", "6", "8", "10", "12", "14", "S", "M", "L", "XL"], nota: "Bastones azul y blanco, escudo bordado." },
  { id: "t2", nombre: "Camiseta suplente 2026", rubro: "Camisetas", precio: 42000, talles: ["6", "8", "10", "12", "S", "M", "L"], nota: "Blanca con vivos azules." },
  { id: "t3", nombre: "Camiseta de arquero", rubro: "Camisetas", precio: 45000, talles: ["8", "10", "12", "M", "L"] },
  { id: "t4", nombre: "Short de juego", rubro: "Camisetas", precio: 19000, talles: ["4", "6", "8", "10", "12", "S", "M", "L"] },
  { id: "t5", nombre: "Medias de juego (par)", rubro: "Camisetas", precio: 9500, talles: ["Chico", "Mediano", "Grande"] },
  { id: "b1", nombre: "Buzo canguro Defe", rubro: "Tiempo libre", precio: 58000, talles: ["6", "8", "10", "12", "S", "M", "L", "XL"], nota: "Frisa peinada, escudo estampado al frente." },
  { id: "b2", nombre: "Buzo de entrenamiento", rubro: "Tiempo libre", precio: 52000, talles: ["8", "10", "12", "S", "M", "L"] },
  { id: "b3", nombre: "Pantalón chupín azul", rubro: "Tiempo libre", precio: 46000, talles: ["6", "8", "10", "12", "S", "M", "L"] },
  { id: "c1", nombre: "Campera rompeviento", rubro: "Camperas", precio: 78000, talles: ["8", "10", "12", "S", "M", "L", "XL"], nota: "Impermeable, con capucha desmontable." },
  { id: "c2", nombre: "Campera inflable Defe", rubro: "Camperas", precio: 96000, talles: ["10", "12", "M", "L", "XL"] },
  { id: "a1", nombre: "Mochila del club", rubro: "Accesorios", precio: 38000, talles: ["Única"] },
  { id: "a2", nombre: "Bolso de botines", rubro: "Accesorios", precio: 21000, talles: ["Única"] },
  { id: "a3", nombre: "Gorra escudo bordado", rubro: "Accesorios", precio: 16000, talles: ["Única"] },
  { id: "a4", nombre: "Botella térmica 750 ml", rubro: "Accesorios", precio: 18500, talles: ["Única"] },
];

const NOVEDADES = [
  { id: "n1", titulo: "Fecha 6: recibimos a Centenario de San Andrés", fecha: "2026-09-07", etiqueta: "Fixture",
    resumen: "Sábado 12 en Ernesto Sábato. Juegan las siete categorías; los horarios se confirman durante la semana.",
    cuerpo: "El Defe llega puntero del Clausura de la Zona H con 84 puntos, dos arriba de Nolting.\n\nPedimos llegar 30 minutos antes del horario de cada categoría para el control de fichas. Si llueve, la suspensión se avisa por la app antes de las 7 de la mañana." },
  { id: "n2", titulo: "La 2015 sigue con puntaje ideal", fecha: "2026-09-06", etiqueta: "Resultados",
    resumen: "Cinco fechas, cinco triunfos. Es la única categoría del club que todavía no cedió puntos en el Clausura.",
    cuerpo: "Con el 5 a 3 a Coronel Brandsen, la categoría 2015 llegó a 15 puntos sobre 15 posibles y lidera su tabla.\n\nLa 2019 y la 2018 también están primeras, ambas con 14 unidades." },
  { id: "n3", titulo: "Llegó la camiseta titular 2026 a la tienda", fecha: "2026-09-03", etiqueta: "Tienda",
    resumen: "Disponible en talles de niños y adultos. Se retira por la sede o en el predio los sábados.",
    cuerpo: "La nueva titular mantiene los bastones azul y blanco y suma el escudo bordado. Hay talles del 4 al 14 y de S a XL.\n\nSe reserva desde la sección Tienda y se abona al retirar." },
  { id: "n4", titulo: "Reunión de padres de las categorías chicas", fecha: "2026-08-31", etiqueta: "Club",
    resumen: "Viernes 11 de septiembre a las 19 en el salón del club: organización del cierre de año.",
    cuerpo: "Convocamos a las familias de 2017, 2018 y 2019 para organizar el torneo de cierre y el transporte a los partidos de visitante.\n\nSe pide la presencia de al menos un adulto por familia." },
];

/* ------------------------------ utilidades ------------------------------ */

const DIAS = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"];
const MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];
const AHORA = new Date("2026-09-08T09:00:00");

const d = (iso) => new Date(iso.length === 10 ? iso + "T12:00" : iso);
const fechaLarga = (iso) => { const f = d(iso); return `${DIAS[f.getDay()]} ${f.getDate()} de ${MESES[f.getMonth()]}`; };
const fechaCorta = (iso) => { const f = d(iso); return `${f.getDate()}/${f.getMonth() + 1}`; };
const diasHasta = (iso) => Math.ceil((d(iso) - AHORA) / 86400000);
const plata = (n) => "$" + n.toLocaleString("es-AR");
const esDefe = (n) => n === CLUB || /Santos Lugares/i.test(n);
const corto = (n) => n.replace(CLUB, "DEFE").replace(/"/g, "").replace("C. S. D. ", "").replace("C. A. ", "");

function haceCuanto(iso) {
  if (!iso) return null;
  const h = Math.round((AHORA - new Date(iso)) / 3600000);
  if (h < 1) return "recién";
  if (h < 24) return `hace ${h} h`;
  return `hace ${Math.round(h / 24)} d`;
}

/* Preferencias de quien usa la app sin cuenta: quedan en este teléfono. */
async function guardar(clave, valor) {
  try { localStorage.setItem(clave, JSON.stringify(valor)); } catch (e) {}
}
async function leer(clave) {
  try {
    const v = localStorage.getItem(clave);
    return v ? JSON.parse(v) : null;
  } catch (e) { return null; }
}

/* ------------------------------- piezas ------------------------------- */

function Escudo({ size = 34 }) {
  return (
    <svg width={size} height={size * 1.15} viewBox="0 0 40 46" aria-label="Escudo del club">
      <path d="M1 2h38v25c0 10-9 15-19 20C10 42 1 37 1 27z" fill="#fff" />
      <path d="M3.5 4.5h33v22c0 8.8-7.8 13-16.5 17.5C11.3 39.5 3.5 35.3 3.5 26.5z" fill={C.azul} />
      <rect x="3.5" y="19.5" width="33" height="7.5" fill="#fff" />
      <rect x="9" y="16.5" width="22" height="13.5" fill={C.azul} />
      <text x="20" y="27.5" textAnchor="middle" fontSize="12" fontWeight="700" fill="#fff"
        style={{ fontFamily: "Barlow, sans-serif", letterSpacing: 0.6 }}>D·S·L</text>
    </svg>
  );
}

function ChipLiga({ liga, chico }) {
  const { LIGAS } = useLigasApp();
  const l = LIGAS[liga];
  return (
    <span className="inline-flex items-center rounded-full font-semibold"
      style={{ background: l.tono + "1A", color: l.tono, fontSize: chico ? 10 : 11, padding: chico ? "2px 7px" : "3px 9px" }}>
      {l.nombre}
    </span>
  );
}

function SelloOrigen({ origen, cuando, fuente = "FEFI" }) {
  const auto = origen === "auto";
  return (
    <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5"
      style={{ background: auto ? "#E8F5EF" : "#FFF4DE", color: auto ? C.gana : "#8A6100", fontSize: 10.5, fontWeight: 600 }}>
      {auto ? <CloudDownload size={11} /> : <Pencil size={11} />}
      {auto ? `${fuente} ${cuando || ""}` : "cargado a mano"}
    </span>
  );
}

function Estrella({ activo, onClick, size = 20 }) {
  return (
    <button onClick={(e) => { e.stopPropagation(); onClick(); }} className="rounded-full p-1" style={{ lineHeight: 0 }}
      aria-label={activo ? "Quitar de mis categorías" : "Agregar a mis categorías"}>
      <Star size={size} strokeWidth={2} style={{ color: activo ? C.oro : "#B8C1D1" }} fill={activo ? C.oro : "none"} />
    </button>
  );
}

function ComoLlegar({ destino, claro }) {
  if (!destino || /confirmar/i.test(destino)) return null;
  return (
    <a href={comoLlegar(destino)} target="_blank" rel="noopener noreferrer"
      onClick={(e) => e.stopPropagation()}
      className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold"
      style={{
        background: claro ? "rgba(255,255,255,.16)" : C.azulTinte,
        color: claro ? "#fff" : C.azul,
      }}>
      <Navigation size={13} /> Cómo llegar
    </a>
  );
}

function Marcador({ m }) {
  if (m === "GP") return <span className="font-bold" style={{ color: C.gana, fontSize: 13 }}>G.P.</span>;
  const [a, b] = m;
  const color = a > b ? C.gana : a === b ? C.empata : C.pierde;
  return <span style={{ fontFamily: "Anton, sans-serif", fontSize: 18, color }}>{a}-{b}</span>;
}

/* ------------------------------ pantallas ------------------------------ */

function Inicio({ favs, toggleFav, irA, abrirNovedad, horarios }) {
  const { LIGAS, ENCUENTROS_FEFI, HORARIOS_FEFI } = useLigasApp();
  const proximo = ENCUENTROS_FEFI.find((e) => !e.jugado && d(e.fecha) >= AHORA);
  const ultimo = [...ENCUENTROS_FEFI].reverse().find((e) => e.jugado);
  const cats = LIGAS.fefi.categorias;
  const mias = favs.length ? cats.filter((c) => favs.includes(c)) : cats;
  const faltan = diasHasta(proximo.fecha);
  const oficial = HORARIOS_FEFI[proximo.nro];
  const horario = horarios[`${proximo.nro}`];
  const horas = oficial ? Object.entries(oficial.horas) : [];
  const enOrden = horas.sort((a, b) => a[1].localeCompare(b[1]));

  return (
    <div className="space-y-6 px-4 pb-6">
      {favs.length === 0 && (
        <div className="rounded-2xl p-4" style={{ background: C.azulTinte, border: `1px solid ${C.linea}` }}>
          <div className="mb-1 font-semibold">Elegí las categorías de tu familia</div>
          <p className="mb-3 text-sm" style={{ color: C.gris }}>
            Marcá con la estrella las que seguís y la app te muestra primero sus resultados y horarios.
          </p>
          <button onClick={() => irA("partidos")} className="rounded-full px-4 py-2 text-sm font-semibold text-white" style={{ background: C.azul }}>
            Elegir categorías
          </button>
        </div>
      )}

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-semibold" style={{ fontSize: 17 }}>Próxima fecha</h2>
          <SelloOrigen origen="auto" cuando={haceCuanto(LIGAS.fefi.actualizado)} />
        </div>

        <div className="overflow-hidden rounded-2xl" style={{ background: C.azul, color: "#fff" }}>
          <div style={{ height: 6, background: `repeating-linear-gradient(90deg, ${C.oro} 0 14px, ${C.azulVivo} 14px 28px)` }} />
          <div className="p-4">
            <div className="mb-3 flex items-center gap-2">
              <ChipLiga liga="fefi" chico />
              <span className="text-sm font-semibold">Fecha {proximo.nro} · Clausura</span>
              <span className="ml-auto text-xs font-semibold" style={{ color: C.oro }}>
                {faltan <= 0 ? "hoy" : faltan === 1 ? "mañana" : `en ${faltan} días`}
              </span>
            </div>
            <div style={{ fontFamily: "Anton, sans-serif", fontSize: 24, lineHeight: 1.15, letterSpacing: 0.4 }}>
              {proximo.local ? `DEFE vs ${corto(proximo.rival)}` : `${corto(proximo.rival)} vs DEFE`}
            </div>
            <div className="mt-3 space-y-1 text-sm" style={{ color: "rgba(255,255,255,.85)" }}>
              <div>{fechaLarga(proximo.fecha)} · {proximo.local ? "local" : "visitante"}</div>
              <div className="flex items-start gap-1"><MapPin size={14} className="mt-0.5 shrink-0" />{proximo.sede}</div>
              <div className="flex items-center gap-1">
                <Clock size={14} />
                {oficial
                  ? `de ${enOrden[0][1]} a ${enOrden[enOrden.length - 1][1]}${oficial.entrada ? ` · entrada ${plata(oficial.entrada)}` : ""}`
                  : horario || "horarios por categoría a confirmar"}
              </div>
              <div className="pt-1"><ComoLlegar destino={proximo.sede} claro /></div>
            </div>
          </div>
        </div>
        {oficial ? (
          <div className="mt-3 overflow-hidden rounded-2xl bg-white" style={{ border: `1px solid ${C.linea}` }}>
            <div className="flex items-center justify-between px-4 py-2.5" style={{ background: "#F7F9FD" }}>
              <span className="text-xs font-semibold" style={{ color: C.gris }}>Horario de cada categoría</span>
              <SelloOrigen origen="manual" />
            </div>
            {enOrden.map(([cat, hora], i) => {
              const mia = favs.includes(cat);
              return (
                <div key={cat} className="flex items-center gap-3 px-4 py-2.5"
                  style={{ borderTop: i ? `1px solid ${C.linea}` : "none", background: mia ? C.azulTinte : "#fff" }}>
                  <span className="w-14 font-semibold">{cat}</span>
                  <span className="flex-1" style={{ fontFamily: "Anton, sans-serif", fontSize: 19 }}>{hora}</span>
                  <Estrella activo={mia} onClick={() => toggleFav(cat)} size={18} />
                </div>
              );
            })}
          </div>
        ) : (
          <button onClick={() => irA("datos")} className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-xl py-2 text-sm font-semibold"
            style={{ border: `1px dashed ${C.linea}`, background: "#fff", color: C.azul }}>
            <Pencil size={14} /> Cargar los horarios de la fecha
          </button>
        )}
      </section>

      <section>
        <h2 className="mb-1 font-semibold" style={{ fontSize: 17 }}>
          Fecha {ultimo.nro} · {ultimo.local ? "vs " + corto(ultimo.rival) : "en " + corto(ultimo.rival)}
        </h2>
        <p className="mb-3 text-xs" style={{ color: C.gris }}>
          {fechaLarga(ultimo.fecha)} · el club ganó la fecha {ultimo.pts[0]} a {ultimo.pts[1]}
          {ultimo.estado === "previo" && " · a verificar"}
        </p>
        <div className="overflow-hidden rounded-2xl bg-white" style={{ border: `1px solid ${C.linea}` }}>
          {mias.map((cat, i) => (
            <div key={cat} className="flex items-center gap-3 px-4 py-2.5" style={{ borderTop: i ? `1px solid ${C.linea}` : "none" }}>
              <span className="w-14 font-semibold">{cat}</span>
              <span className="flex-1"><Marcador m={ultimo.marc[cat]} /></span>
              <Estrella activo={favs.includes(cat)} onClick={() => toggleFav(cat)} size={18} />
            </div>
          ))}
        </div>
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-semibold" style={{ fontSize: 17 }}>Futsal</h2>
          <SelloOrigen origen="auto" fuente="Superliga" cuando={haceCuanto(LIGAS.superliga.actualizado)} />
        </div>
        <button onClick={() => irA("partidos")} className="w-full rounded-2xl bg-white p-4 text-left" style={{ border: `1px solid ${C.linea}` }}>
          <div className="mb-1 flex items-center gap-2">
            <ChipLiga liga="superliga" chico />
            <span className="text-xs font-semibold" style={{ color: C.gris }}>Junior A · fecha 4</span>
          </div>
          <div className="font-semibold">All Boys 0 - 3 Defe</div>
          <p className="mt-1 text-sm" style={{ color: C.gris }}>
            Tres partidos, tres triunfos: el equipo está cuarto con 9 puntos, a uno de la punta.
          </p>
        </button>
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-semibold" style={{ fontSize: 17 }}>Novedades</h2>
          <button onClick={() => irA("novedades")} className="text-sm font-semibold" style={{ color: C.azul }}>Ver todas</button>
        </div>
        <div className="space-y-3">
          {NOVEDADES.slice(0, 2).map((n) => (
            <button key={n.id} onClick={() => abrirNovedad(n)} className="w-full rounded-2xl bg-white p-4 text-left" style={{ border: `1px solid ${C.linea}` }}>
              <div className="mb-1 text-xs font-semibold" style={{ color: C.azulVivo }}>{n.etiqueta}</div>
              <div className="font-semibold leading-snug">{n.titulo}</div>
              <p className="mt-1 text-sm" style={{ color: C.gris }}>{n.resumen}</p>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

function SelectorLiga({ liga, setLiga }) {
  const { LIGAS } = useLigasApp();
  const disciplinas = ["Baby fútbol", "Futsal"];
  const disc = LIGAS[liga].disciplina;
  const delDeporte = Object.entries(LIGAS).filter(([, l]) => l.disciplina === disc);

  return (
    <div className="mb-4 px-4 pt-1">
      <div className="mb-3 flex rounded-xl p-1" style={{ background: "#E4E9F2" }}>
        {disciplinas.map((dd) => (
          <button key={dd} onClick={() => {
            const primera = Object.entries(LIGAS).find(([, l]) => l.disciplina === dd);
            if (primera) setLiga(primera[0]);
          }}
            className="flex-1 rounded-lg py-2 text-sm font-semibold"
            style={{ background: disc === dd ? "#fff" : "transparent", color: disc === dd ? C.azul : C.gris }}>
            {dd}
          </button>
        ))}
      </div>
      <div className="overflow-x-auto">
        <div className="flex gap-2 pb-1">
          {delDeporte.map(([k, l]) => (
            <button key={k} onClick={() => setLiga(k)}
              className="flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-3.5 py-2 text-sm font-semibold"
              style={{ background: liga === k ? C.azul : "#fff", color: liga === k ? "#fff" : C.tinta, border: `1px solid ${liga === k ? C.azul : C.linea}` }}>
              {l.nombre}
              {!l.conectada && <AlertCircle size={13} style={{ opacity: 0.7 }} />}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function SinFuente({ liga, irA }) {
  const { LIGAS } = useLigasApp();
  return (
    <div className="mx-4 rounded-2xl bg-white p-6 text-center" style={{ border: `1px solid ${C.linea}` }}>
      <p className="font-semibold">{LIGAS[liga].nombre} todavía no está conectada</p>
      <p className="mt-1 text-sm" style={{ color: C.gris }}>
        {LIGAS[liga].pendiente} Mientras tanto se carga a mano.
      </p>
      <button onClick={() => irA("datos")} className="mt-3 rounded-full px-4 py-2 text-sm font-semibold text-white" style={{ background: C.azul }}>
        Cargar un partido
      </button>
    </div>
  );
}

function Segmento({ vista, setVista }) {
  return (
    <div className="mb-4 flex rounded-xl p-1" style={{ background: "#E4E9F2" }}>
      {[["fixture", "Fixture"], ["resultados", "Resultados"], ["posiciones", "Posiciones"]].map(([k, label]) => (
        <button key={k} onClick={() => setVista(k)} className="flex-1 rounded-lg py-2 text-sm font-semibold"
          style={{ background: vista === k ? "#fff" : "transparent", color: vista === k ? C.azul : C.gris }}>
          {label}
        </button>
      ))}
    </div>
  );
}

function Partidos({ favs, toggleFav, liga, setLiga, manuales, horarios, irA }) {
  const { LIGAS, ENCUENTROS_FEFI, SUPERLIGA, LAAMBA, HORARIOS_FEFI } = useLigasApp();
  const [vista, setVista] = useState("fixture");

  if (vista === "posiciones") {
    return <Posiciones favs={favs} liga={liga} setLiga={setLiga} irA={irA} vista={vista} setVista={setVista} />;
  }

  if (LIGAS[liga].tipo === "simple" && LIGAS[liga].conectada) {
    const D = liga === "superliga" ? SUPERLIGA : LAAMBA;
    return (
      <div className="pb-6">
        <SelectorLiga liga={liga} setLiga={setLiga} />
        <div className="px-4">
          <Segmento vista={vista} setVista={setVista} />
          <div className="mb-3 flex items-center justify-between">
            <span className="text-sm font-semibold" style={{ color: C.gris }}>{LIGAS[liga].torneo}</span>
            <SelloOrigen origen="auto" fuente={LIGAS[liga].nombre} cuando={haceCuanto(LIGAS[liga].actualizado)} />
          </div>
          {D.partidos.length === 0 && (
            <div className="rounded-2xl bg-white p-6 text-center" style={{ border: `1px solid ${C.linea}` }}>
              <p className="font-semibold">Todavía sin fixture cargado</p>
              <p className="mt-1 text-sm" style={{ color: C.gris }}>
                La tabla de posiciones ya está. El fixture entra en la próxima sincronización.
              </p>
            </div>
          )}
          <div className="space-y-3">
            {[...D.partidos].reverse().map((p) => (
              <div key={p.nro} className="overflow-hidden rounded-2xl bg-white" style={{ border: `1px solid ${C.linea}` }}>
                <div className="px-4 py-2.5 text-xs font-semibold" style={{ background: "#F7F9FD", color: C.gris }}>
                  Fecha {p.nro} · {fechaCorta(p.fecha)}
                </div>
                <div className="px-4 py-3">
                  {p.rival ? (
                    <>
                      <div className="flex items-center justify-between">
                        <span className="font-semibold">{p.local ? `Defe vs ${p.rival}` : `${p.rival} vs Defe`}</span>
                        <span style={{ fontFamily: "Anton, sans-serif", fontSize: 22, color: p.gf > p.gc ? C.gana : p.gf === p.gc ? C.empata : C.pierde }}>
                          {p.local ? `${p.gf}-${p.gc}` : `${p.gc}-${p.gf}`}
                        </span>
                      </div>
                      <div className="mt-1 flex items-center gap-3 text-xs" style={{ color: C.gris }}>
                        <span className="flex items-center gap-1"><MapPin size={12} />{p.sede}</span>
                        <span className="flex items-center gap-1"><Clock size={12} />{p.hora} h</span>
                      </div>
                      <div className="mt-2"><ComoLlegar destino={p.sede ? `${p.sede}, Buenos Aires` : null} /></div>
                    </>
                  ) : (
                    <div className="text-sm" style={{ color: C.gris }}>
                      La liga todavía no publicó el detalle de esta fecha.
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          <p className="mt-3 text-xs" style={{ color: C.gris }}>
            El futsal juega los lunes por la noche. La liga publica sede y horario durante la semana.
          </p>
        </div>
      </div>
    );
  }

  if (!LIGAS[liga].conectada) {
    const propios = manuales.filter((m) => m.liga === liga);
    return (
      <div className="pb-6">
        <SelectorLiga liga={liga} setLiga={setLiga} />
        {propios.length === 0 ? <SinFuente liga={liga} irA={irA} /> : (
          <div className="space-y-3 px-4">
            {propios.map((m) => (
              <div key={m.id} className="rounded-2xl bg-white p-4" style={{ border: `1px solid ${C.linea}` }}>
                <div className="mb-1 flex items-center gap-2">
                  <ChipLiga liga={m.liga} chico />
                  <span className="text-xs font-semibold" style={{ color: C.gris }}>Categoría {m.categoria}</span>
                  <span className="ml-auto"><SelloOrigen origen="manual" /></span>
                </div>
                <div className="font-semibold">{m.local ? `Defe vs ${m.rival}` : `${m.rival} vs Defe`}</div>
                <div className="mt-1 text-sm" style={{ color: C.gris }}>
                  {fechaLarga(m.fecha)}{m.hora ? ` · ${m.hora}` : ""}{m.sede ? ` · ${m.sede}` : ""}
                </div>
                {m.resultado && <div className="mt-1 font-bold" style={{ color: C.azul }}>Resultado: {m.resultado}</div>}
                {m.sede && <div className="mt-2"><ComoLlegar destino={`${m.sede}, Buenos Aires`} /></div>}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  const lista = ENCUENTROS_FEFI.filter((e) => (vista === "fixture" ? !e.jugado : e.jugado));
  const orden = vista === "fixture" ? lista : [...lista].reverse();
  const cats = LIGAS.fefi.categorias;
  const mias = favs.length ? cats.filter((c) => favs.includes(c)) : cats;

  return (
    <div className="pb-6">
      <SelectorLiga liga={liga} setLiga={setLiga} />
      <div className="px-4">
        <div className="mb-3 flex items-center justify-between">
          <span className="text-sm font-semibold" style={{ color: C.gris }}>{LIGAS.fefi.torneo}</span>
          <SelloOrigen origen="auto" cuando={haceCuanto(LIGAS.fefi.actualizado)} />
        </div>

        <Segmento vista={vista} setVista={setVista} />

        <div className="space-y-3">
          {orden.map((e) => (
            <div key={e.nro} className="overflow-hidden rounded-2xl bg-white" style={{ border: `1px solid ${C.linea}` }}>
              <div className="flex items-center gap-2 px-4 py-2.5" style={{ background: "#F7F9FD" }}>
                <span className="text-xs font-semibold" style={{ color: C.gris }}>Fecha {e.nro} · {fechaCorta(e.fecha)}</span>
                {e.estado === "previo" && (
                  <span className="rounded px-1.5 py-0.5 text-xs font-semibold" style={{ background: "#FFF4DE", color: "#8A6100" }}>a verificar</span>
                )}
                {e.jugado && (
                  <span className="ml-auto font-bold" style={{ color: e.pts[0] > e.pts[1] ? C.gana : e.pts[0] === e.pts[1] ? C.empata : C.pierde }}>
                    {e.pts[0]} - {e.pts[1]}
                  </span>
                )}
              </div>
              <div className="px-4 py-3">
                <div className="font-semibold">{e.local ? `Defe vs ${corto(e.rival)}` : `${corto(e.rival)} vs Defe`}</div>
                <div className="mt-0.5 flex items-start gap-1 text-xs" style={{ color: C.gris }}>
                  <MapPin size={12} className="mt-0.5 shrink-0" />{e.sede}
                </div>
                {!e.jugado && (
                  <div className="mt-1 flex items-center gap-1 text-xs" style={{ color: C.gris }}>
                    <Clock size={12} />
                    {HORARIOS_FEFI[e.nro]
                      ? Object.entries(HORARIOS_FEFI[e.nro].horas)
                          .filter(([c]) => (favs.length ? favs.includes(c) : true))
                          .sort((a, b) => a[1].localeCompare(b[1]))
                          .map(([c, h]) => `${c} ${h}`).join(" · ")
                      : horarios[`${e.nro}`] || "horarios a confirmar"}
                  </div>
                )}
                {!e.jugado && <div className="mt-2"><ComoLlegar destino={e.sede} /></div>}
                {e.jugado && (
                  <div className="mt-3 grid grid-cols-2 gap-x-4">
                    {mias.map((c) => (
                      <div key={c} className="flex items-center justify-between border-b py-1" style={{ borderColor: C.linea }}>
                        <span className="text-sm font-semibold">{c}</span>
                        <Marcador m={e.marc[c]} />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-5">
          <div className="mb-2 text-sm font-semibold">Mis categorías</div>
          <div className="flex flex-wrap gap-2">
            {cats.map((c) => (
              <button key={c} onClick={() => toggleFav(c)} className="flex items-center gap-1.5 rounded-full px-3 py-2 text-sm font-semibold"
                style={{ background: favs.includes(c) ? C.azulTinte : "#fff", border: `1px solid ${favs.includes(c) ? C.azulVivo : C.linea}` }}>
                <Star size={14} fill={favs.includes(c) ? C.oro : "none"} style={{ color: favs.includes(c) ? C.oro : "#B8C1D1" }} />
                {c}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Posiciones({ favs, liga, setLiga, irA, vista, setVista }) {
  const { LIGAS, TABLAS, SUPERLIGA, LAAMBA } = useLigasApp();
  const [tabla, setTabla] = useState("general");

  if (LIGAS[liga].tipo === "simple" && LIGAS[liga].conectada) {
    const D = liga === "superliga" ? SUPERLIGA : LAAMBA;
    const divisiones = LIGAS[liga].categorias;
    const clave = D.tablas[tabla] ? tabla : Object.keys(D.tablas)[0];
    const filas = D.tablas[divisiones.includes(tabla) ? tabla : clave];

    return (
      <div className="pb-6">
        <SelectorLiga liga={liga} setLiga={setLiga} />
        {setVista && <div className="px-4"><Segmento vista={vista} setVista={setVista} /></div>}
        <div className="mb-3 flex items-center justify-between px-4">
          <span className="text-sm font-semibold" style={{ color: C.gris }}>{LIGAS[liga].torneo}</span>
          <SelloOrigen origen="auto" fuente={LIGAS[liga].nombre} cuando={haceCuanto(LIGAS[liga].actualizado)} />
        </div>

        {divisiones.length > 1 && (
          <div className="mb-4 overflow-x-auto px-4">
            <div className="flex gap-2">
              {divisiones.map((dv) => (
                <button key={dv} onClick={() => setTabla(dv)} className="shrink-0 rounded-xl px-3 py-2 text-sm font-semibold"
                  style={{ background: tabla === dv ? C.azulTinte : "#fff", border: `1px solid ${tabla === dv ? C.azulVivo : C.linea}`, color: tabla === dv ? C.azul : C.tinta }}>
                  {dv}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="px-4">
          {!filas ? (
            <div className="rounded-2xl bg-white p-6 text-center" style={{ border: `1px solid ${C.linea}` }}>
              <p className="font-semibold">Esta división entra en la próxima sincronización</p>
              <p className="mt-1 text-sm" style={{ color: C.gris }}>
                El club juega de 1ra a 8va en M - Elite I y la 1ra femenina en F - Ascenso I Zona B.
              </p>
            </div>
          ) : (
          <div className="overflow-hidden rounded-2xl bg-white" style={{ border: `1px solid ${C.linea}` }}>
            <div className="grid items-center px-3 py-2 text-xs font-semibold"
              style={{ gridTemplateColumns: "20px 1fr 26px 48px 32px", color: C.gris, background: "#F7F9FD" }}>
              <span></span><span>Equipo</span><span className="text-center">PJ</span><span className="text-center">G-E-P</span><span className="text-center">Pts</span>
            </div>
            {filas.map((f, i) => {
              const nuestro = esDefe(f.equipo);
              return (
                <div key={f.equipo} className="grid items-center px-3 py-2.5 text-sm"
                  style={{ gridTemplateColumns: "20px 1fr 26px 48px 32px", borderTop: `1px solid ${C.linea}`, background: nuestro ? C.azulTinte : "#fff" }}>
                  <span style={{ color: C.gris, fontSize: 12 }}>{i + 1}</span>
                  <span className="truncate" style={{ fontWeight: nuestro ? 700 : 400 }}>{nuestro ? "DEFE" : f.equipo}</span>
                  <span className="text-center" style={{ color: C.gris }}>{f.pj}</span>
                  <span className="text-center text-xs" style={{ color: C.gris }}>{f.g}-{f.e}-{f.p}</span>
                  <span className="text-center font-bold">{f.pts}</span>
                </div>
              );
            })}
          </div>
          )}
        </div>
      </div>
    );
  }

  if (!LIGAS[liga].conectada) {
    return (<div className="pb-6"><SelectorLiga liga={liga} setLiga={setLiga} /><SinFuente liga={liga} irA={irA} /></div>);
  }
  const opciones = ["general", ...LIGAS.fefi.categorias];
  const filas = TABLAS[tabla];

  return (
    <div className="pb-6">
      <SelectorLiga liga={liga} setLiga={setLiga} />
      {setVista && <div className="px-4"><Segmento vista={vista} setVista={setVista} /></div>}
      <div className="mb-3 flex items-center justify-between px-4">
        <span className="text-sm font-semibold" style={{ color: C.gris }}>{LIGAS.fefi.torneo}</span>
        <SelloOrigen origen="auto" cuando={haceCuanto(LIGAS.fefi.actualizado)} />
      </div>

      <div className="mb-4 overflow-x-auto px-4">
        <div className="flex gap-2">
          {opciones.map((o) => (
            <button key={o} onClick={() => setTabla(o)} className="shrink-0 rounded-xl px-3 py-2 text-sm font-semibold"
              style={{ background: tabla === o ? C.azulTinte : "#fff", border: `1px solid ${tabla === o ? C.azulVivo : C.linea}`, color: tabla === o ? C.azul : C.tinta }}>
              {o === "general" ? "General" : o}{favs.includes(o) ? " ★" : ""}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4">
        <div className="overflow-hidden rounded-2xl bg-white" style={{ border: `1px solid ${C.linea}` }}>
          <div className="grid items-center px-3 py-2 text-xs font-semibold"
            style={{ gridTemplateColumns: "20px 1fr 26px 48px 32px", color: C.gris, background: "#F7F9FD" }}>
            <span></span><span>Equipo</span><span className="text-center">PJ</span><span className="text-center">G-E-P</span><span className="text-center">Pts</span>
          </div>
          {filas.map((f, i) => {
            const nuestro = esDefe(f.equipo);
            return (
              <div key={f.equipo + i} className="grid items-center px-3 py-2.5 text-sm"
                style={{ gridTemplateColumns: "20px 1fr 26px 48px 32px", borderTop: `1px solid ${C.linea}`, background: nuestro ? C.azulTinte : "#fff" }}>
                <span style={{ color: C.gris, fontSize: 12 }}>{i + 1}</span>
                <span className="truncate" style={{ fontWeight: nuestro ? 700 : 400 }}>{nuestro ? "DEFE" : corto(f.equipo)}</span>
                <span className="text-center" style={{ color: C.gris }}>{f.pj}</span>
                <span className="text-center text-xs" style={{ color: C.gris }}>{f.g}-{f.e}-{f.p}</span>
                <span className="text-center font-bold">{f.pts}</span>
              </div>
            );
          })}
        </div>
        <p className="mt-2 text-xs" style={{ color: C.gris }}>
          En FEFI el partido ganado suma 3, el empatado 2 y el perdido 1. La general acumula las siete categorías.
        </p>
      </div>
    </div>
  );
}

function Tienda({ productos, carrito, agregar, abrirCarrito }) {
  const rubros = ["Todo", "Camisetas", "Tiempo libre", "Camperas", "Accesorios"];
  const [rubro, setRubro] = useState("Todo");
  const [busca, setBusca] = useState("");
  const [detalle, setDetalle] = useState(null);

  const lista = productos
    .filter((p) => p.visible !== false)
    .filter((p) => (rubro === "Todo" ? true : p.rubro === rubro))
    .filter((p) => (busca.trim() ? (p.nombre + " " + (p.nota || "")).toLowerCase().includes(busca.toLowerCase()) : true));
  const items = carrito.reduce((s, i) => s + i.cant, 0);

  return (
    <div className="pb-6">
      <div className="px-4 pt-1">
        <input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar en la tienda"
          className="mb-3 w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
      </div>
      <div className="mb-4 overflow-x-auto px-4">
        <div className="flex gap-2 pb-1">
          {rubros.map((r) => (
            <button key={r} onClick={() => setRubro(r)} className="shrink-0 rounded-full px-3.5 py-2 text-sm font-semibold"
              style={{ background: rubro === r ? C.azul : "#fff", color: rubro === r ? "#fff" : C.tinta, border: `1px solid ${rubro === r ? C.azul : C.linea}` }}>
              {r}
            </button>
          ))}
        </div>
      </div>

      {lista.length === 0 && (
        <div className="mx-4 rounded-2xl bg-white p-6 text-center" style={{ border: `1px solid ${C.linea}` }}>
          <p className="font-semibold">No encontramos ese producto</p>
          <p className="mt-1 text-sm" style={{ color: C.gris }}>Probá con otra palabra o mirá todas las categorías.</p>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 px-4">
        {lista.map((p) => {
          const sinStock = p.stock && Object.values(p.stock).every((c) => c <= 0);
          return (
            <button key={p.id} onClick={() => setDetalle(p)} className="overflow-hidden rounded-2xl bg-white text-left" style={{ border: `1px solid ${C.linea}` }}>
              <div className="relative flex items-center justify-center" style={{
                height: 110,
                background: p.rubro === "Camisetas" ? `repeating-linear-gradient(90deg, ${C.azul} 0 12px, #fff 12px 24px)`
                  : p.rubro === "Camperas" ? C.azul : p.rubro === "Tiempo libre" ? "#12306E" : C.azulTinte,
                opacity: sinStock ? 0.5 : 1,
              }}>
                <Escudo size={40} />
                {p.destacado && (
                  <span className="absolute left-2 top-2 rounded px-1.5 py-0.5 text-xs font-semibold"
                    style={{ background: C.oro, color: "#3A2C00" }}>Destacado</span>
                )}
              </div>
              <div className="p-3">
                <div className="text-sm font-semibold leading-snug">{p.nombre}</div>
                <div className="mt-1 font-bold" style={{ color: p.precio ? C.azul : C.gris, fontSize: p.precio ? 16 : 13 }}>
                  {p.precio ? plata(p.precio) : "Precio a confirmar"}
                </div>
                {sinStock && <div className="mt-1 text-xs font-semibold" style={{ color: C.pierde }}>Sin stock</div>}
              </div>
            </button>
          );
        })}
      </div>

      <p className="mt-4 px-4 text-xs" style={{ color: C.gris }}>
        El pedido se registra en la app y se envía por WhatsApp a la tienda del club ({TIENDA.instagram}).
        Ahí confirman y se abona al retirar por la sede o en el predio los sábados.
      </p>

      {items > 0 && (
        <div className="fixed bottom-20 left-0 right-0 flex justify-center px-4" style={{ zIndex: 30 }}>
          <button onClick={abrirCarrito} className="flex w-full items-center justify-between rounded-full px-5 py-3 text-white shadow-lg"
            style={{ background: C.azul, maxWidth: 398 }}>
            <span className="font-semibold">Ver pedido ({items})</span>
            <span className="font-bold">{plata(carrito.reduce((s, i) => s + (i.precio || 0) * i.cant, 0))}</span>
          </button>
        </div>
      )}

      {detalle && <FichaProducto producto={detalle} carrito={carrito} cerrar={() => setDetalle(null)} agregar={agregar} />}
    </div>
  );
}

function FichaProducto({ producto, carrito, cerrar, agregar }) {
  const disponibles = producto.stock
    ? producto.talles.filter((t) => (producto.stock[t] || 0) > 0)
    : producto.talles;
  const [talle, setTalle] = useState(disponibles[0] || producto.talles[0]);
  const [ok, setOk] = useState(false);

  const enCarrito = carrito.find((i) => i.key === producto.id + "-" + talle)?.cant || 0;
  const tope = producto.stock ? (producto.stock[talle] || 0) : Infinity;
  const puede = disponibles.includes(talle) && enCarrito < tope;

  return (
    <div className="fixed inset-0 flex items-end justify-center" style={{ zIndex: 60, background: "rgba(16,24,40,.45)" }}>
      <div className="w-full overflow-hidden rounded-t-3xl bg-white" style={{ maxWidth: 430 }}>
        <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: `1px solid ${C.linea}` }}>
          <span className="font-semibold">{producto.nombre}</span>
          <button onClick={cerrar} aria-label="Cerrar"><X size={20} style={{ color: C.gris }} /></button>
        </div>
        <div className="max-h-96 overflow-y-auto p-4">
          <div className="mb-4 flex h-32 items-center justify-center rounded-2xl"
            style={{ background: producto.rubro === "Camisetas" ? `repeating-linear-gradient(90deg, ${C.azul} 0 14px, #fff 14px 28px)` : C.azulTinte }}>
            <Escudo size={52} />
          </div>
          <div className="mb-1 text-2xl font-bold" style={{ color: producto.precio ? C.azul : C.gris }}>
            {producto.precio ? plata(producto.precio) : "Precio a confirmar"}
          </div>
          {producto.nota && <p className="mb-4 text-sm" style={{ color: C.gris }}>{producto.nota}</p>}

          <div className="mb-2 text-sm font-semibold">Talle</div>
          <div className="mb-2 flex flex-wrap gap-2">
            {producto.talles.map((t) => {
              const hay = !producto.stock || (producto.stock[t] || 0) > 0;
              return (
                <button key={t} onClick={() => hay && setTalle(t)} disabled={!hay}
                  className="rounded-lg px-3 py-2 text-sm font-semibold"
                  style={{
                    background: talle === t ? C.azul : "#fff",
                    color: !hay ? "#C3CAD6" : talle === t ? "#fff" : C.tinta,
                    border: `1px solid ${talle === t ? C.azul : C.linea}`,
                    textDecoration: hay ? "none" : "line-through",
                  }}>
                  {t}
                </button>
              );
            })}
          </div>
          <div className="text-xs" style={{ color: C.gris }}>
            {producto.stock ? `Quedan ${tope} en talle ${talle}` : "Disponibilidad a confirmar con la tienda"}
          </div>
        </div>
        <div className="p-4" style={{ borderTop: `1px solid ${C.linea}` }}>
          <button onClick={() => { agregar(producto, talle); setOk(true); setTimeout(cerrar, 700); }}
            disabled={!puede}
            className="flex w-full items-center justify-center gap-2 rounded-xl py-3 font-semibold text-white"
            style={{ background: !puede ? "#B8C1D1" : ok ? C.gana : C.azul }}>
            {ok ? (<><Check size={18} /> Agregado</>) : puede ? "Agregar al pedido" : "Sin stock en ese talle"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Carrito({ carrito, cerrar, crear, tienda }) {
  const [datos, setDatos] = useState({ nombre: "", telefono: "", categoria: "", retiro: "sede", nota: "" });
  const [hecho, setHecho] = useState(null);
  const [ocupado, setOcupado] = useState(false);
  const [error, setError] = useState(null);

  const retiros = { sede: "Retiro por la sede del club", predio: "Retiro en el predio, el sábado" };
  const falta = !datos.nombre.trim() || datos.telefono.replace(/\D/g, "").length < 8;

  const armarTexto = (nro) => [
    `Hola! Pedido #${nro} de la tienda del Defe.`,
    `Soy ${datos.nombre}${datos.categoria ? ` (${datos.categoria})` : ""}. Tel: ${datos.telefono}`,
    "",
    ...carrito.items.map((i) => `• ${i.cant} x ${i.nombre} — talle ${i.talle}${i.precio ? ` — ${plata(i.precio * i.cant)}` : " — a confirmar"}`),
    "",
    carrito.aConfirmar ? `Total parcial: ${plata(carrito.total)} (hay productos a confirmar)` : `Total: ${plata(carrito.total)}`,
    retiros[datos.retiro],
    datos.nota ? `Nota: ${datos.nota}` : null,
  ].filter((l) => l !== null).join("\n");

  const confirmar = async () => {
    setOcupado(true);
    const { pedido, error: err } = await crear({
      ...datos, retiro: retiros[datos.retiro], total: carrito.total, items: carrito.items,
    });
    setOcupado(false);
    if (err || !pedido) return setError("No pudimos registrar el pedido. Probá de nuevo.");
    const texto = armarTexto(pedido.nro);
    setHecho({ nro: pedido.nro, texto });
    window.open(`https://wa.me/${tienda?.whatsapp || ""}?text=${encodeURIComponent(texto)}`, "_blank", "noopener");
  };

  if (hecho) {
    return (
      <div className="fixed inset-0 flex items-end justify-center" style={{ zIndex: 70, background: "rgba(16,24,40,.45)" }}>
        <div className="w-full rounded-t-3xl bg-white p-6 text-center" style={{ maxWidth: 430 }}>
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full" style={{ background: C.gana + "22" }}>
            <Check size={24} style={{ color: C.gana }} />
          </div>
          <div className="text-lg font-bold">Pedido #{hecho.nro} registrado</div>
          <p className="mt-1 text-sm" style={{ color: C.gris }}>
            Se abrió WhatsApp con el detalle. Si no se abrió, copialo y mandalo desde ahí.
            La tienda confirma y te avisa cuando está listo.
          </p>
          <button onClick={() => { try { navigator.clipboard.writeText(hecho.texto); } catch (e) {} }}
            className="mt-4 w-full rounded-xl py-2.5 text-sm font-semibold" style={{ border: `1px solid ${C.linea}`, color: C.azul }}>
            Copiar el pedido
          </button>
          <button onClick={() => { carrito.vaciar(); cerrar(); }}
            className="mt-2 w-full rounded-xl py-3 font-semibold text-white" style={{ background: C.azul }}>
            Listo
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 flex items-end justify-center" style={{ zIndex: 70, background: "rgba(16,24,40,.45)" }}>
      <div className="w-full rounded-t-3xl bg-white" style={{ maxWidth: 430 }}>
        <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: `1px solid ${C.linea}` }}>
          <span className="font-semibold">Tu pedido</span>
          <button onClick={cerrar} aria-label="Cerrar"><X size={20} style={{ color: C.gris }} /></button>
        </div>

        <div className="max-h-80 overflow-y-auto">
          {carrito.items.map((i) => (
            <div key={i.key} className="flex items-center gap-3 px-4 py-3" style={{ borderBottom: `1px solid ${C.linea}` }}>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-semibold">{i.nombre}</div>
                <div className="text-xs" style={{ color: C.gris }}>
                  Talle {i.talle} · {i.precio ? plata(i.precio) : "a confirmar"}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => carrito.cambiar(i.key, -1)} className="rounded-full p-1.5" style={{ border: `1px solid ${C.linea}` }}><Minus size={14} /></button>
                <span className="w-5 text-center font-semibold">{i.cant}</span>
                <button onClick={() => carrito.cambiar(i.key, 1)} className="rounded-full p-1.5" style={{ border: `1px solid ${C.linea}` }}><Plus size={14} /></button>
              </div>
            </div>
          ))}

          <div className="space-y-2 px-4 py-3">
            <input value={datos.nombre} onChange={(e) => setDatos({ ...datos, nombre: e.target.value })}
              placeholder="Nombre y apellido"
              className="w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
            <input value={datos.telefono} onChange={(e) => setDatos({ ...datos, telefono: e.target.value })}
              placeholder="Teléfono" inputMode="tel"
              className="w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
            <input value={datos.categoria} onChange={(e) => setDatos({ ...datos, categoria: e.target.value })}
              placeholder="Categoría o equipo (opcional)"
              className="w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
            <div className="flex gap-2">
              {Object.keys(retiros).map((k) => (
                <button key={k} onClick={() => setDatos({ ...datos, retiro: k })}
                  className="flex-1 rounded-lg px-2 py-2 text-xs font-semibold"
                  style={{ background: datos.retiro === k ? C.azulTinte : "#fff", border: `1px solid ${datos.retiro === k ? C.azulVivo : C.linea}` }}>
                  {k === "sede" ? "Por la sede" : "En el predio"}
                </button>
              ))}
            </div>
            <input value={datos.nota} onChange={(e) => setDatos({ ...datos, nota: e.target.value })}
              placeholder="Observaciones (opcional)"
              className="w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
          </div>
        </div>

        <div className="p-4" style={{ borderTop: `1px solid ${C.linea}` }}>
          <div className="mb-3 flex items-center justify-between">
            <span style={{ color: C.gris }}>{carrito.aConfirmar ? "Total parcial" : "Total"}</span>
            <span className="text-xl font-bold">{plata(carrito.total)}</span>
          </div>
          <button onClick={confirmar} disabled={falta || ocupado}
            className="flex w-full items-center justify-center gap-2 rounded-xl py-3 font-semibold text-white"
            style={{ background: falta || ocupado ? "#B8C1D1" : "#25D366" }}>
            <MessageCircle size={18} /> {ocupado ? "Registrando…" : "Registrar y enviar por WhatsApp"}
          </button>
          <p className="mt-2 text-center text-xs" style={{ color: error ? C.pierde : C.gris }}>
            {error || (falta
              ? "Completá nombre y teléfono para que la tienda pueda responderte."
              : carrito.aConfirmar
                ? "Hay productos sin precio: la tienda lo confirma antes de preparar el pedido."
                : "Queda registrado con número y se abre el chat con el detalle escrito.")}
          </p>
        </div>
      </div>
    </div>
  );
}

function Novedades({ abrirNovedad }) {
  return (
    <div className="space-y-3 px-4 pb-6">
      {NOVEDADES.map((n) => (
        <button key={n.id} onClick={() => abrirNovedad(n)} className="w-full overflow-hidden rounded-2xl bg-white text-left" style={{ border: `1px solid ${C.linea}` }}>
          <div style={{ height: 4, background: C.azulVivo }} />
          <div className="p-4">
            <div className="mb-1 flex items-center gap-2">
              <span className="text-xs font-semibold" style={{ color: C.azulVivo }}>{n.etiqueta}</span>
              <span className="text-xs" style={{ color: C.gris }}>· {fechaCorta(n.fecha)}</span>
            </div>
            <div className="font-semibold leading-snug">{n.titulo}</div>
            <p className="mt-1 text-sm" style={{ color: C.gris }}>{n.resumen}</p>
          </div>
        </button>
      ))}
    </div>
  );
}

function DetalleNovedad({ nota, cerrar }) {
  return (
    <div className="fixed inset-0 bg-white" style={{ zIndex: 80, overflowY: "auto" }}>
      <div className="mx-auto" style={{ maxWidth: 430 }}>
        <div className="sticky top-0 flex items-center gap-2 bg-white px-3 py-3" style={{ borderBottom: `1px solid ${C.linea}` }}>
          <button onClick={cerrar} className="p-1" aria-label="Volver"><ChevronLeft size={22} /></button>
          <span className="font-semibold">Novedades</span>
        </div>
        <div className="p-4">
          <div className="mb-2 flex items-center gap-2">
            <span className="text-xs font-semibold" style={{ color: C.azulVivo }}>{nota.etiqueta}</span>
            <span className="text-xs" style={{ color: C.gris }}>· {fechaLarga(nota.fecha)}</span>
          </div>
          <h1 className="mb-4 text-2xl font-bold leading-tight">{nota.titulo}</h1>
          {nota.cuerpo.split("\n\n").map((p, i) => <p key={i} className="mb-3" style={{ lineHeight: 1.6 }}>{p}</p>)}
        </div>
      </div>
    </div>
  );
}

/* ============================ PLANTELES ============================ */
/* Datos de ejemplo: se reemplazan por las listas de buena fe del club. */

const PLANTELES = {
  "FEFI 2015": [
    { n: 1, nombre: "Bautista Ferreyra", puesto: "Arquero" },
    { n: 4, nombre: "Thiago Almada", puesto: "Defensor" },
    { n: 5, nombre: "Lorenzo Paz", puesto: "Defensor" },
    { n: 7, nombre: "Ciro Medina", puesto: "Mediocampista", goles: 11 },
    { n: 8, nombre: "Benjamín Rossi", puesto: "Mediocampista", goles: 4 },
    { n: 9, nombre: "Valentino Sosa", puesto: "Delantero", goles: 14 },
    { n: 10, nombre: "Mateo Giménez", puesto: "Delantero", goles: 9 },
    { n: 11, nombre: "Lautaro Vega", puesto: "Delantero", goles: 6 },
  ],
  "FEFI 2018": [
    { n: 1, nombre: "Felipe Cabrera", puesto: "Arquero" },
    { n: 3, nombre: "Bruno Ledesma", puesto: "Defensor" },
    { n: 6, nombre: "Santino Ríos", puesto: "Mediocampista", goles: 7 },
    { n: 9, nombre: "Joaquín Molina", puesto: "Delantero", goles: 13 },
    { n: 10, nombre: "Dante Aguirre", puesto: "Delantero", goles: 8 },
  ],
  "LAAMBA 1ra": [
    { n: 1, nombre: "Nicolás Ponce", puesto: "Arquero" },
    { n: 4, nombre: "Emiliano Vidal", puesto: "Cierre" },
    { n: 5, nombre: "Franco Sosa", puesto: "Ala", goles: 8 },
    { n: 7, nombre: "Gastón Ferrari", puesto: "Ala", goles: 6 },
    { n: 9, nombre: "Hernán Duarte", puesto: "Pivot", goles: 12 },
    { n: 10, nombre: "Diego Arias", puesto: "Ala", goles: 5 },
  ],
  "Superliga Junior A": [
    { n: 1, nombre: "Tomás Bianchi", puesto: "Arquero" },
    { n: 5, nombre: "Iván Cortés", puesto: "Cierre" },
    { n: 8, nombre: "Manuel Peralta", puesto: "Ala", goles: 4 },
    { n: 9, nombre: "Agustín Roldán", puesto: "Pivot", goles: 7 },
  ],
};

const JUGADOR_FECHA = {
  nombre: "Valentino Sosa", plantel: "FEFI 2015", partido: "Fecha 5 vs Coronel Brandsen",
  comentario: "Hizo tres goles y sostuvo el invicto de la categoría. Quinta victoria en cinco fechas.",
};

const GALERIA = [
  { id: "g1", titulo: "Fecha 5 en Brandsen", descripcion: "Las siete categorías, jornada completa de visitante.", fecha: "2026-09-05" },
  { id: "g2", titulo: "La 2015, puntaje ideal", descripcion: "Festejo después del 5 a 3.", fecha: "2026-09-05" },
  { id: "g3", titulo: "Futsal: 3 a 0 a All Boys", descripcion: "Junior A en el CEDEM N° 1.", fecha: "2026-08-31" },
  { id: "g4", titulo: "Entrega de camisetas 2026", descripcion: "Las categorías chicas estrenaron la titular.", fecha: "2026-08-23" },
];

function Planteles({ abrirJugador }) {
  const nombres = Object.keys(PLANTELES);
  const [plantel, setPlantel] = useState(nombres[0]);
  const jugadores = PLANTELES[plantel];

  return (
    <div className="pb-6">
      <div className="mb-4 overflow-x-auto px-4 pt-1">
        <div className="flex gap-2 pb-1">
          {nombres.map((p) => (
            <button key={p} onClick={() => setPlantel(p)}
              className="shrink-0 whitespace-nowrap rounded-full px-3.5 py-2 text-sm font-semibold"
              style={{ background: plantel === p ? C.azul : "#fff", color: plantel === p ? "#fff" : C.tinta, border: `1px solid ${plantel === p ? C.azul : C.linea}` }}>
              {p}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-sm font-semibold" style={{ color: C.gris }}>{jugadores.length} jugadores</span>
          <SelloOrigen origen="manual" />
        </div>
        <div className="overflow-hidden rounded-2xl bg-white" style={{ border: `1px solid ${C.linea}` }}>
          {jugadores.map((j, i) => (
            <button key={j.n} onClick={() => abrirJugador({ ...j, plantel })}
              className="flex w-full items-center gap-3 px-4 py-3 text-left"
              style={{ borderTop: i ? `1px solid ${C.linea}` : "none" }}>
              <span className="flex h-8 w-8 items-center justify-center rounded-full font-bold"
                style={{ background: C.azulTinte, color: C.azul, fontSize: 13 }}>{j.n}</span>
              <div className="flex-1">
                <div className="font-semibold">{j.nombre}</div>
                <div className="text-xs" style={{ color: C.gris }}>{j.puesto}</div>
              </div>
              {j.goles ? <span className="text-xs font-semibold" style={{ color: C.gris }}>{j.goles} goles</span> : null}
              <ChevronRight size={16} style={{ color: "#B8C1D1" }} />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function FichaJugador({ jugador, cerrar }) {
  return (
    <div className="fixed inset-0 flex items-end justify-center" style={{ zIndex: 70, background: "rgba(16,24,40,.45)" }}>
      <div className="w-full rounded-t-3xl bg-white" style={{ maxWidth: 430 }}>
        <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: `1px solid ${C.linea}` }}>
          <span className="font-semibold">Perfil del jugador</span>
          <button onClick={cerrar} aria-label="Cerrar"><X size={20} style={{ color: C.gris }} /></button>
        </div>
        <div className="p-5">
          <div className="flex items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-full" style={{ background: C.azul }}>
              <span style={{ fontFamily: "Anton, sans-serif", fontSize: 26, color: "#fff" }}>{jugador.n}</span>
            </div>
            <div>
              <div className="text-xl font-bold leading-tight">{jugador.nombre}</div>
              <div className="text-sm" style={{ color: C.gris }}>{jugador.puesto} · {jugador.plantel}</div>
            </div>
          </div>
          <div className="mt-5 grid grid-cols-2 gap-3">
            <div className="rounded-xl p-3" style={{ background: C.azulTinte }}>
              <div style={{ fontFamily: "Anton, sans-serif", fontSize: 24, color: C.azul }}>{jugador.goles || 0}</div>
              <div className="text-xs" style={{ color: C.gris }}>goles en el torneo</div>
            </div>
            <div className="rounded-xl p-3" style={{ background: "#F5F7FB" }}>
              <div style={{ fontFamily: "Anton, sans-serif", fontSize: 24 }}>{jugador.n}</div>
              <div className="text-xs" style={{ color: C.gris }}>número</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================ COMUNIDAD ============================ */

function Comunidad({ abrirNovedad, abrirJugador }) {
  const [vista, setVista] = useState("destacados");
  const goleadores = Object.entries(PLANTELES)
    .flatMap(([plantel, js]) => js.filter((j) => j.goles).map((j) => ({ ...j, plantel })))
    .sort((a, b) => b.goles - a.goles)
    .slice(0, 10);

  return (
    <div className="pb-6">
      <div className="mb-4 px-4 pt-1">
        <div className="flex rounded-xl p-1" style={{ background: "#E4E9F2" }}>
          {[["destacados", "Destacados"], ["galeria", "Galería"], ["novedades", "Novedades"]].map(([k, label]) => (
            <button key={k} onClick={() => setVista(k)} className="flex-1 rounded-lg py-2 text-sm font-semibold"
              style={{ background: vista === k ? "#fff" : "transparent", color: vista === k ? C.azul : C.gris }}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {vista === "destacados" && (
        <div className="space-y-5 px-4">
          <section>
            <h2 className="mb-3 font-semibold" style={{ fontSize: 17 }}>Jugador de la fecha</h2>
            <div className="overflow-hidden rounded-2xl" style={{ background: C.azul, color: "#fff" }}>
              <div style={{ height: 5, background: C.oro }} />
              <div className="p-4">
                <div style={{ fontFamily: "Anton, sans-serif", fontSize: 22 }}>{JUGADOR_FECHA.nombre.toUpperCase()}</div>
                <div className="text-sm" style={{ opacity: 0.85 }}>{JUGADOR_FECHA.plantel} · {JUGADOR_FECHA.partido}</div>
                <p className="mt-2 text-sm" style={{ opacity: 0.9 }}>{JUGADOR_FECHA.comentario}</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="mb-3 font-semibold" style={{ fontSize: 17 }}>Goleadores del club</h2>
            <div className="overflow-hidden rounded-2xl bg-white" style={{ border: `1px solid ${C.linea}` }}>
              {goleadores.map((j, i) => (
                <button key={j.plantel + j.n} onClick={() => abrirJugador(j)}
                  className="flex w-full items-center gap-3 px-4 py-2.5 text-left"
                  style={{ borderTop: i ? `1px solid ${C.linea}` : "none" }}>
                  <span className="w-5 text-center text-xs" style={{ color: C.gris }}>{i + 1}</span>
                  <div className="flex-1">
                    <div className="text-sm font-semibold">{j.nombre}</div>
                    <div className="text-xs" style={{ color: C.gris }}>{j.plantel}</div>
                  </div>
                  <span style={{ fontFamily: "Anton, sans-serif", fontSize: 20, color: C.azul }}>{j.goles}</span>
                </button>
              ))}
            </div>
          </section>
        </div>
      )}

      {vista === "galeria" && (
        <div className="grid grid-cols-2 gap-3 px-4">
          {GALERIA.map((g, i) => (
            <div key={g.id} className="overflow-hidden rounded-2xl bg-white" style={{ border: `1px solid ${C.linea}` }}>
              <div className="flex items-center justify-center" style={{
                height: 100,
                background: i % 2 ? `repeating-linear-gradient(90deg, ${C.azul} 0 12px, #fff 12px 24px)` : C.azul,
              }}>
                <Escudo size={34} />
              </div>
              <div className="p-3">
                <div className="text-sm font-semibold leading-snug">{g.titulo}</div>
                <p className="mt-1 text-xs" style={{ color: C.gris }}>{g.descripcion}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {vista === "novedades" && <Novedades abrirNovedad={abrirNovedad} />}
    </div>
  );
}

/* ============================= MI DEFE ============================= */

const PREFS = [
  ["cambios", "Cambios de horario o cancha"],
  ["resultados", "Resultados al terminar la fecha"],
  ["novedades", "Novedades del club"],
  ["convocatorias", "Convocatorias"],
  ["soloFavoritos", "Solo de mis categorías"],
];

function MiDefe({ usuario, prefs, setPrefs, favs, entrar, registrarse, salir, irA }) {
  const [form, setForm] = useState({ email: "", clave: "", nombre: "" });
  const [modo, setModo] = useState("entrar");
  const [aviso, setAviso] = useState(null);
  const [ocupado, setOcupado] = useState(false);

  const enviar = async () => {
    setOcupado(true);
    const error = modo === "entrar"
      ? await entrar(form.email, form.clave)
      : await registrarse(form.email, form.clave, form.nombre);
    setOcupado(false);
    if (error) return setAviso(error);
    setAviso(modo === "crear" ? "Cuenta creada. Revisá tu email para confirmarla." : null);
  };

  if (!usuario) {
    return (
      <div className="px-4 pb-6">
        <div className="rounded-2xl bg-white p-5" style={{ border: `1px solid ${C.linea}` }}>
          <div className="mb-1 font-semibold">{modo === "entrar" ? "Entrar a Mi Defe" : "Crear cuenta"}</div>
          <p className="mb-4 text-sm" style={{ color: C.gris }}>
            Tus categorías y tus avisos te siguen a cualquier teléfono. También podés usar
            la app sin cuenta.
          </p>
          <div className="space-y-2">
            {modo === "crear" && (
              <input value={form.nombre} onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                placeholder="Nombre y apellido"
                className="w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
            )}
            <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="Email" inputMode="email" autoComplete="email"
              className="w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
            <input value={form.clave} onChange={(e) => setForm({ ...form, clave: e.target.value })}
              placeholder="Contraseña" type="password"
              className="w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
          </div>
          {aviso && <p className="mt-2 text-xs" style={{ color: C.pierde }}>{aviso}</p>}
          <button onClick={enviar} disabled={ocupado}
            className="mt-3 w-full rounded-xl py-3 font-semibold text-white"
            style={{ background: ocupado ? "#B8C1D1" : C.azul }}>
            {ocupado ? "Un momento…" : modo === "entrar" ? "Ingresar" : "Crear cuenta"}
          </button>
          <button onClick={() => { setModo(modo === "entrar" ? "crear" : "entrar"); setAviso(null); }}
            className="mt-2 w-full py-2 text-sm font-semibold" style={{ color: C.azul }}>
            {modo === "entrar" ? "No tengo cuenta" : "Ya tengo cuenta"}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 px-4 pb-6">
      <div className="rounded-2xl bg-white p-4" style={{ border: `1px solid ${C.linea}` }}>
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-full" style={{ background: C.azulTinte }}>
            <Escudo size={22} />
          </div>
          <div className="flex-1">
            <div className="font-semibold">{usuario.nombre || usuario.email}</div>
            <div className="text-xs" style={{ color: C.gris }}>
              {usuario.admin ? "Dirigente · con acceso a Gestión" : "Socio"} · {favs.length} categoría(s) seguidas
            </div>
          </div>
        </div>
        <button onClick={salir} className="mt-3 w-full rounded-xl py-2.5 text-sm font-semibold"
          style={{ border: `1px solid ${C.linea}` }}>
          Cerrar sesión
        </button>
      </div>

      <div className="overflow-hidden rounded-2xl bg-white" style={{ border: `1px solid ${C.linea}` }}>
        <div className="px-4 py-3 font-semibold" style={{ borderBottom: `1px solid ${C.linea}` }}>Notificaciones</div>
        {PREFS.map(([k, label]) => (
          <button key={k} onClick={() => setPrefs({ ...prefs, [k]: !prefs[k] })}
            className="flex w-full items-center gap-3 px-4 py-3 text-left" style={{ borderBottom: `1px solid ${C.linea}` }}>
            <span className="flex-1 text-sm">{label}</span>
            <span className="rounded-full px-2.5 py-1 text-xs font-semibold"
              style={{ background: prefs[k] ? C.azul : "#E4E9F2", color: prefs[k] ? "#fff" : C.gris }}>
              {prefs[k] ? "Sí" : "No"}
            </span>
          </button>
        ))}
        <BotonAvisos perfilId={usuario.id} />
      </div>

      {usuario.admin && (
        <button onClick={() => irA("gestion")} className="flex w-full items-center justify-between rounded-2xl bg-white p-4"
          style={{ border: `1px solid ${C.linea}` }}>
          <div className="text-left">
            <div className="font-semibold">Gestión</div>
            <div className="text-xs" style={{ color: C.gris }}>Tienda, pedidos, contenidos y fuentes</div>
          </div>
          <ChevronRight size={18} style={{ color: C.gris }} />
        </button>
      )}
    </div>
  );
}

/* El permiso del teléfono. Si no se puede (iPhone sin instalar, permiso
   bloqueado), se explica el motivo en vez de dejar un botón que no hace nada. */
function BotonAvisos({ perfilId }) {
  const [estado, setEstado] = useState({ puede: false });
  const [activo, setActivo] = useState(false);
  const [mensaje, setMensaje] = useState(null);
  const [ocupado, setOcupado] = useState(false);

  useEffect(() => {
    setEstado(estadoPush());
    estaSuscripto().then(setActivo);
    return escucharRenovacion(perfilId);
  }, [perfilId]);

  const alternar = async () => {
    setOcupado(true);
    const r = activo ? await desactivarAvisos() : await activarAvisos(perfilId);
    setOcupado(false);
    if (r.error) return setMensaje(r.error);
    setMensaje(null);
    setActivo(!activo);
  };

  return (
    <div className="p-4">
      <button onClick={alternar} disabled={!estado.puede || ocupado}
        className="flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold"
        style={{
          background: !estado.puede ? "#E4E9F2" : activo ? "#fff" : C.azul,
          color: !estado.puede ? C.gris : activo ? C.azul : "#fff",
          border: activo ? `1px solid ${C.linea}` : "none",
        }}>
        {activo ? <BellOff size={16} /> : <Bell size={16} />}
        {ocupado ? "Un momento…" : activo ? "Desactivar avisos en este teléfono" : "Activar notificaciones del dispositivo"}
      </button>
      {(mensaje || estado.motivo) && (
        <p className="mt-2 text-xs" style={{ color: C.gris }}>{mensaje || estado.motivo}</p>
      )}
    </div>
  );
}

/* ============================= GESTIÓN ============================= */

const ESTADOS = ["pendiente", "en preparación", "listo", "entregado", "cancelado"];
const COLOR_ESTADO = {
  pendiente: "#C99A00", "en preparación": C.azulVivo, listo: C.gana,
  entregado: C.gris, cancelado: C.pierde,
};

function Gestion({ productos, guardarProducto, guardarStock, pedidos, tienda, guardarConfig,
  horarios, guardarHorarios, manuales, guardarPartido, borrarManual }) {
  const { LIGAS, ENCUENTROS_FEFI } = useLigasApp();
  const [seccion, setSeccion] = useState("pedidos");
  const [editando, setEditando] = useState(null);
  const [stockDe, setStockDe] = useState(null);
  const [verHistorial, setVerHistorial] = useState(false);
  const [whatsapp, setWhatsapp] = useState(tienda?.whatsapp || "");
  const [form, setForm] = useState(null);
  const [horaFecha, setHoraFecha] = useState("");

  const proximo = ENCUENTROS_FEFI.find((e) => !e.jugado) || {};
  const lista = verHistorial ? pedidos.historial : pedidos.activos;

  return (
    <div className="pb-6">
      <div className="mb-4 px-4 pt-1">
        <div className="flex rounded-xl p-1" style={{ background: "#E4E9F2" }}>
          {[["pedidos", "Pedidos"], ["catalogo", "Catálogo"], ["fuentes", "Fuentes"]].map(([k, label]) => (
            <button key={k} onClick={() => setSeccion(k)} className="flex-1 rounded-lg py-2 text-sm font-semibold"
              style={{ background: seccion === k ? "#fff" : "transparent", color: seccion === k ? C.azul : C.gris }}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {seccion === "pedidos" && (
        <div className="space-y-4 px-4">
          <div className="grid grid-cols-3 gap-2">
            {["pendiente", "en preparación", "listo"].map((e) => (
              <div key={e} className="rounded-2xl bg-white p-3 text-center" style={{ border: `1px solid ${C.linea}` }}>
                <div style={{ fontFamily: "Anton, sans-serif", fontSize: 24, color: COLOR_ESTADO[e] }}>{pedidos.cuenta(e)}</div>
                <div className="text-xs capitalize" style={{ color: C.gris }}>{e}</div>
              </div>
            ))}
          </div>

          <div className="flex rounded-xl p-1" style={{ background: "#E4E9F2" }}>
            {[[false, `Activos (${pedidos.activos.length})`], [true, `Historial (${pedidos.historial.length})`]].map(([v, label]) => (
              <button key={String(v)} onClick={() => setVerHistorial(v)} className="flex-1 rounded-lg py-2 text-sm font-semibold"
                style={{ background: verHistorial === v ? "#fff" : "transparent", color: verHistorial === v ? C.azul : C.gris }}>
                {label}
              </button>
            ))}
          </div>

          {lista.length === 0 && (
            <div className="rounded-2xl bg-white p-6 text-center" style={{ border: `1px solid ${C.linea}` }}>
              <p className="font-semibold">{verHistorial ? "Todavía no hay pedidos cerrados" : "No hay pedidos en curso"}</p>
              <p className="mt-1 text-sm" style={{ color: C.gris }}>Los de la Tienda entran acá como pendientes, sin refrescar.</p>
            </div>
          )}

          {lista.map((p) => (
            <div key={p.id || p.nro} className="overflow-hidden rounded-2xl bg-white" style={{ border: `1px solid ${C.linea}` }}>
              <div className="flex items-center gap-2 px-4 py-2.5" style={{ background: "#F7F9FD" }}>
                <span className="text-xs font-semibold" style={{ color: C.gris }}>Pedido #{p.nro}</span>
                <span className="ml-auto rounded-full px-2 py-0.5 text-xs font-semibold capitalize"
                  style={{ background: COLOR_ESTADO[p.estado] + "1F", color: COLOR_ESTADO[p.estado] }}>{p.estado}</span>
              </div>
              <div className="px-4 py-3">
                <div className="font-semibold">{p.nombre}</div>
                <div className="text-xs" style={{ color: C.gris }}>
                  {[p.categoria, p.telefono, p.retiro].filter(Boolean).join(" · ")}
                </div>
                <div className="mt-2 space-y-0.5 text-sm">
                  {(p.pedido_items || p.items || []).map((i, n) => (
                    <div key={i.id || n} style={{ color: C.gris }}>
                      {i.cantidad || i.cant} x {i.nombre} — talle {i.talle}
                    </div>
                  ))}
                </div>
                {p.nota && <div className="mt-1 text-xs" style={{ color: C.gris }}>Nota: {p.nota}</div>}
                <div className="mt-2 font-bold" style={{ color: C.azul }}>{plata(p.total)}</div>

                <div className="mt-3 flex flex-wrap gap-2">
                  {ESTADOS.filter((e) => e !== p.estado).map((e) => (
                    <button key={e} onClick={() => pedidos.cambiarEstado(p.id, e)}
                      className="rounded-lg px-2.5 py-1.5 text-xs font-semibold capitalize"
                      style={{ border: `1px solid ${C.linea}`, color: COLOR_ESTADO[e] }}>
                      {e}
                    </button>
                  ))}
                </div>
                {p.telefono && (
                  <a href={`https://wa.me/${p.telefono.replace(/\D/g, "")}?text=${encodeURIComponent(`Hola ${p.nombre}! Tu pedido #${p.nro} del Defe ya está listo para retirar.`)}`}
                    target="_blank" rel="noopener noreferrer"
                    className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold text-white"
                    style={{ background: "#25D366" }}>
                    <MessageCircle size={16} /> Avisarle por WhatsApp
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {seccion === "catalogo" && (
        <div className="space-y-3 px-4">
          <button onClick={() => setEditando({ nombre: "", rubro: "Camisetas", precio: "", talles: "", nota: "", visible: true, destacado: false })}
            className="flex w-full items-center justify-center gap-1.5 rounded-xl py-2.5 text-sm font-semibold"
            style={{ border: `1px dashed ${C.linea}`, color: C.azul }}>
            <Plus size={15} /> Nuevo producto
          </button>

          {productos.map((p) => (
            <div key={p.id} className="rounded-2xl bg-white p-4" style={{ border: `1px solid ${C.linea}` }}>
              <div className="flex items-start gap-2">
                <div className="flex-1">
                  <div className="font-semibold">{p.nombre}</div>
                  <div className="text-xs" style={{ color: C.gris }}>
                    {p.rubro} · {p.precio ? plata(p.precio) : "precio a confirmar"}
                    {p.stock ? " · stock por talle" : ""}
                  </div>
                </div>
                {!p.visible && <span className="rounded px-2 py-0.5 text-xs font-semibold" style={{ background: "#F1F3F7", color: C.gris }}>oculto</span>}
                {p.destacado && <span className="rounded px-2 py-0.5 text-xs font-semibold" style={{ background: C.oro + "22", color: "#8A6100" }}>destacado</span>}
              </div>
              <div className="mt-3 flex gap-2">
                <button onClick={() => setEditando({ ...p, talles: p.talles.join(", "), precio: p.precio ?? "" })}
                  className="flex-1 rounded-lg py-2 text-xs font-semibold" style={{ border: `1px solid ${C.linea}` }}>Editar</button>
                <button onClick={() => setStockDe(p)}
                  className="flex-1 rounded-lg py-2 text-xs font-semibold" style={{ border: `1px solid ${C.linea}` }}>Stock</button>
                <button onClick={() => guardarProducto({ ...p, visible: !p.visible })}
                  className="flex-1 rounded-lg py-2 text-xs font-semibold" style={{ border: `1px solid ${C.linea}` }}>
                  {p.visible ? "Ocultar" : "Mostrar"}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {seccion === "fuentes" && (
        <div className="space-y-4 px-4">
          <div className="rounded-2xl bg-white p-4" style={{ border: `1px solid ${C.linea}` }}>
            <div className="font-semibold">WhatsApp de pedidos</div>
            <p className="mb-3 mt-1 text-sm" style={{ color: C.gris }}>
              Con código de país y área, sin espacios ni signos. Ej: 5491155551234
            </p>
            <input value={whatsapp} onChange={(e) => setWhatsapp(e.target.value.replace(/\D/g, ""))}
              inputMode="numeric" placeholder="5491155551234"
              className="mb-2 w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
            <button onClick={() => guardarConfig({ ...tienda, whatsapp })}
              className="w-full rounded-xl py-2.5 text-sm font-semibold text-white" style={{ background: C.azul }}>
              Guardar número
            </button>
          </div>

          <div className="rounded-2xl bg-white p-4" style={{ border: `1px solid ${C.linea}` }}>
            <div className="mb-2 font-semibold">Fuentes de competencia</div>
            {Object.entries(LIGAS).map(([k, l]) => (
              <div key={k} className="flex items-center gap-2 border-t py-2.5" style={{ borderColor: C.linea }}>
                <ChipLiga liga={k} />
                <div className="flex-1 text-xs" style={{ color: C.gris }}>
                  <div>{l.disciplina}</div>
                  {l.conectada ? `Sincroniza sola · ${haceCuanto(l.actualizado)}` : l.pendiente}
                </div>
                {l.conectada ? <RefreshCw size={16} style={{ color: C.gana }} /> : <AlertCircle size={16} style={{ color: "#C99A00" }} />}
              </div>
            ))}
            <p className="mt-2 text-xs" style={{ color: C.gris }}>
              Las ligas se leen solas varias veces por día. Lo que cargues acá tiene prioridad
              y no se pisa.
            </p>
          </div>

          <div className="rounded-2xl bg-white p-4" style={{ border: `1px solid ${C.linea}` }}>
            <div className="font-semibold">Horarios de la fecha {proximo.nro}</div>
            <p className="mb-3 mt-1 text-sm" style={{ color: C.gris }}>
              FEFI publica el fixture pero no el horario de cada categoría.
            </p>
            {horarios[proximo.nro] && (
              <div className="mb-3 rounded-xl px-3 py-2 text-sm" style={{ background: C.azulTinte }}>
                {Object.entries(horarios[proximo.nro].horas).map(([c, h]) => `${c} ${h}`).join(" · ")}
              </div>
            )}
            <input value={horaFecha} onChange={(e) => setHoraFecha(e.target.value)}
              placeholder="2019 14:30 · 2013 15:15 · 2018 16:10"
              className="mb-2 w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
            <button onClick={async () => {
              if (!horaFecha.trim()) return;
              await guardarHorarios("fefi", proximo.nro, horaFecha.trim());
              setHoraFecha("");
            }} className="w-full rounded-xl py-2.5 text-sm font-semibold text-white" style={{ background: C.azul }}>
              Guardar horarios
            </button>
          </div>

          <div className="rounded-2xl bg-white p-4" style={{ border: `1px solid ${C.linea}` }}>
            <div className="font-semibold">Partidos cargados a mano</div>
            <p className="mb-3 mt-1 text-sm" style={{ color: C.gris }}>
              Para lo que la liga todavía no publica o para un partido reprogramado.
            </p>
            {manuales.map((m) => (
              <div key={m.id} className="flex items-center gap-2 border-t py-2.5 text-sm" style={{ borderColor: C.linea }}>
                <div className="flex-1">
                  <div className="font-semibold">{LIGAS[m.liga]?.nombre} {m.datos?.categoria} · {m.datos?.local ? "vs" : "en"} {m.datos?.rival}</div>
                  <div className="text-xs" style={{ color: C.gris }}>{m.datos?.fecha} {m.datos?.hora || ""}</div>
                </div>
                <button onClick={() => borrarManual(m.id)} aria-label="Borrar"><X size={16} style={{ color: C.gris }} /></button>
              </div>
            ))}
            {!form ? (
              <button onClick={() => setForm({ liga: "lamba", categoria: "", fecha: "", hora: "", rival: "", sede: "", local: true, resultado: "" })}
                className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-xl py-2.5 text-sm font-semibold"
                style={{ border: `1px dashed ${C.linea}`, color: C.azul }}>
                <Plus size={15} /> Agregar partido
              </button>
            ) : (
              <div className="mt-3 space-y-2">
                <div className="flex gap-2">
                  {Object.keys(LIGAS).map((k) => (
                    <button key={k} onClick={() => setForm({ ...form, liga: k })} className="flex-1 rounded-lg py-2 text-xs font-semibold"
                      style={{ background: form.liga === k ? C.azul : "#fff", color: form.liga === k ? "#fff" : C.tinta, border: `1px solid ${form.liga === k ? C.azul : C.linea}` }}>
                      {LIGAS[k].nombre}
                    </button>
                  ))}
                </div>
                <input value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })} placeholder="Categoría o división"
                  className="w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
                <input value={form.rival} onChange={(e) => setForm({ ...form, rival: e.target.value })} placeholder="Rival"
                  className="w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
                <input type="date" value={form.fecha} onChange={(e) => setForm({ ...form, fecha: e.target.value })}
                  className="w-full rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
                <div className="flex gap-2">
                  <input value={form.hora} onChange={(e) => setForm({ ...form, hora: e.target.value })} placeholder="Hora"
                    className="w-24 rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
                  <input value={form.sede} onChange={(e) => setForm({ ...form, sede: e.target.value })} placeholder="Cancha"
                    className="flex-1 rounded-xl px-3 py-2.5 text-sm" style={{ border: `1px solid ${C.linea}` }} />
                </div>
                <div className="flex gap-2">
                  {[[true, "Local"], [false, "Visitante"]].map(([v, label]) => (
                    <button key={label} onClick={() => setForm({ ...form, local: v })} className="flex-1 rounded-lg py-2 text-xs font-semibold"
                      style={{ background: form.local === v ? C.azulTinte : "#fff", border: `1px solid ${form.local === v ? C.azulVivo : C.linea}` }}>
                      {label}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2 pt-1">
                  <button onClick={() => setForm(null)} className="flex-1 rounded-xl py-2.5 text-sm font-semibold" style={{ border: `1px solid ${C.linea}` }}>Cancelar</button>
                  <button onClick={async () => {
                    if (!form.rival || !form.fecha) return;
                    await guardarPartido(form.liga, form);
                    setForm(null);
                  }} className="flex-1 rounded-xl py-2.5 text-sm font-semibold text-white" style={{ background: C.azul }}>
                    Guardar partido
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {editando && <EditorProducto producto={editando} cerrar={() => setEditando(null)}
        guardar={async (p) => { await guardarProducto(p); setEditando(null); }} />}
      {stockDe && <EditorStock producto={stockDe} cerrar={() => setStockDe(null)}
        guardar={async (stock) => { await guardarStock(stockDe.id, stock); setStockDe(null); }} />}
    </div>
  );
}

function EditorProducto({ producto, cerrar, guardar }) {
  const [p, setP] = useState(producto);
  const campo = "w-full rounded-xl px-3 py-2.5 text-sm";
  return (
    <div className="fixed inset-0 flex items-end justify-center" style={{ zIndex: 70, background: "rgba(16,24,40,.45)" }}>
      <div className="w-full rounded-t-3xl bg-white" style={{ maxWidth: 430 }}>
        <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: `1px solid ${C.linea}` }}>
          <span className="font-semibold">{p.id ? "Editar producto" : "Nuevo producto"}</span>
          <button onClick={cerrar} aria-label="Cerrar"><X size={20} style={{ color: C.gris }} /></button>
        </div>
        <div className="max-h-96 space-y-2 overflow-y-auto p-4">
          <input value={p.nombre} onChange={(e) => setP({ ...p, nombre: e.target.value })} placeholder="Nombre" className={campo} style={{ border: `1px solid ${C.linea}` }} />
          <div className="flex gap-2">
            {["Camisetas", "Tiempo libre", "Camperas", "Accesorios"].map((r) => (
              <button key={r} onClick={() => setP({ ...p, rubro: r })} className="flex-1 rounded-lg px-1 py-2 text-xs font-semibold"
                style={{ background: p.rubro === r ? C.azulTinte : "#fff", border: `1px solid ${p.rubro === r ? C.azulVivo : C.linea}` }}>
                {r.split(" ")[0]}
              </button>
            ))}
          </div>
          <input value={p.precio} onChange={(e) => setP({ ...p, precio: e.target.value })} inputMode="numeric"
            placeholder="Precio (vacío = a confirmar)" className={campo} style={{ border: `1px solid ${C.linea}` }} />
          <input value={p.talles} onChange={(e) => setP({ ...p, talles: e.target.value })}
            placeholder="Talles separados por coma: 8, 10, 12, M, L" className={campo} style={{ border: `1px solid ${C.linea}` }} />
          <input value={p.nota || ""} onChange={(e) => setP({ ...p, nota: e.target.value })}
            placeholder="Descripción" className={campo} style={{ border: `1px solid ${C.linea}` }} />
          <div className="flex gap-2">
            {[["visible", "Visible"], ["destacado", "Destacado"]].map(([k, label]) => (
              <button key={k} onClick={() => setP({ ...p, [k]: !p[k] })} className="flex-1 rounded-lg py-2 text-xs font-semibold"
                style={{ background: p[k] ? C.azulTinte : "#fff", border: `1px solid ${p[k] ? C.azulVivo : C.linea}` }}>
                {label}: {p[k] ? "sí" : "no"}
              </button>
            ))}
          </div>
        </div>
        <div className="p-4" style={{ borderTop: `1px solid ${C.linea}` }}>
          <button onClick={() => guardar({
            ...p,
            precio: p.precio === "" ? null : Number(p.precio),
            talles: String(p.talles).split(",").map((t) => t.trim()).filter(Boolean),
          })}
            disabled={!p.nombre}
            className="w-full rounded-xl py-3 font-semibold text-white" style={{ background: p.nombre ? C.azul : "#B8C1D1" }}>
            Guardar producto
          </button>
        </div>
      </div>
    </div>
  );
}

function EditorStock({ producto, cerrar, guardar }) {
  const [activo, setActivo] = useState(!!producto.stock);
  const [stock, setStock] = useState(
    producto.stock || Object.fromEntries(producto.talles.map((t) => [t, 0]))
  );
  return (
    <div className="fixed inset-0 flex items-end justify-center" style={{ zIndex: 70, background: "rgba(16,24,40,.45)" }}>
      <div className="w-full rounded-t-3xl bg-white" style={{ maxWidth: 430 }}>
        <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: `1px solid ${C.linea}` }}>
          <span className="font-semibold">Stock · {producto.nombre}</span>
          <button onClick={cerrar} aria-label="Cerrar"><X size={20} style={{ color: C.gris }} /></button>
        </div>
        <div className="p-4">
          <button onClick={() => setActivo(!activo)} className="mb-3 flex w-full items-center gap-3 rounded-xl px-3 py-2.5"
            style={{ background: activo ? C.azulTinte : "#F5F7FB" }}>
            <span className="flex-1 text-left text-sm font-semibold">Controlar stock por talle</span>
            <span className="rounded-full px-2 py-0.5 text-xs font-semibold"
              style={{ background: activo ? C.azul : "#D5DBE6", color: activo ? "#fff" : C.gris }}>{activo ? "Sí" : "No"}</span>
          </button>

          {activo && (
            <div className="max-h-72 overflow-y-auto">
              {producto.talles.map((t) => (
                <div key={t} className="flex items-center gap-3 border-b py-2" style={{ borderColor: C.linea }}>
                  <span className="w-16 text-sm font-semibold">Talle {t}</span>
                  <div className="ml-auto flex items-center gap-2">
                    <button onClick={() => setStock({ ...stock, [t]: Math.max(0, (stock[t] || 0) - 1) })}
                      className="rounded-full p-1.5" style={{ border: `1px solid ${C.linea}` }}><Minus size={14} /></button>
                    <span className="w-8 text-center font-semibold">{stock[t] || 0}</span>
                    <button onClick={() => setStock({ ...stock, [t]: (stock[t] || 0) + 1 })}
                      className="rounded-full p-1.5" style={{ border: `1px solid ${C.linea}` }}><Plus size={14} /></button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <button onClick={() => guardar(activo ? stock : null)}
            className="mt-4 w-full rounded-xl py-3 font-semibold text-white" style={{ background: C.azul }}>
            Guardar stock
          </button>
          {!activo && (
            <p className="mt-2 text-center text-xs" style={{ color: C.gris }}>
              Sin control de stock, la disponibilidad queda a confirmar con la tienda.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

/* -------------------------------- app -------------------------------- */

/* Los datos que traía escritos el prototipo quedan como respaldo: si la
   sincronización no responde y el teléfono no tiene copia, la app abre
   igual con la última foto conocida en lugar de una pantalla vacía. */
const RESPALDO = { LIGAS, ENCUENTROS_FEFI, TABLAS, SUPERLIGA, LAAMBA, HORARIOS_FEFI };

const ContextoLigas = createContext(RESPALDO);
function useLigasApp() { return useContext(ContextoLigas); }

/* "2019 14:30 · 2013 15:15" → { "2019": "14:30", "2013": "15:15" } */
function leerHorarios(texto) {
  const horas = {};
  String(texto).split(/[·|,;]/).forEach((t) => {
    const m = t.trim().match(/(\S+)\s+(\d{1,2})[:.](\d{2})/);
    if (m) horas[m[1]] = `${m[2].padStart(2, "0")}:${m[3]}`;
  });
  return horas;
}

/* Pasa lo que publica la sincronización a la forma que usan las pantallas. */
function armarLigas(remoto) {
  if (!remoto?.ligas?.length) return RESPALDO;
  const salida = { ...RESPALDO, LIGAS: { ...RESPALDO.LIGAS } };

  for (const l of remoto.ligas) {
    const base = RESPALDO.LIGAS[l.id] || {};
    salida.LIGAS[l.id] = {
      ...base,
      nombre: l.nombre ?? base.nombre,
      torneo: l.torneo ?? base.torneo,
      fuente: l.fuente ?? base.fuente,
      conectada: Boolean(l.conectada),
      actualizado: l.actualizado ?? base.actualizado,
      categorias: l.categorias?.length ? l.categorias : base.categorias,
    };

    const tablas = l.tablas && Object.keys(l.tablas).length ? l.tablas : null;

    if (l.id === "fefi") {
      if (l.encuentros?.length) {
        salida.ENCUENTROS_FEFI = l.encuentros.map((e) => ({
          ...e,
          jugado: Boolean(e.marc),
          sede: e.sede || (e.local ? SEDE_LOCAL : "A confirmar"),
        }));
      }
      if (tablas) salida.TABLAS = tablas;
    }
    if (l.id === "superliga" && (l.partidos || tablas)) {
      salida.SUPERLIGA = { partidos: l.partidos ?? [], tablas: tablas ?? RESPALDO.SUPERLIGA.tablas };
    }
    if (l.id === "lamba" && (l.partidos || tablas)) {
      salida.LAAMBA = { partidos: l.partidos ?? [], tablas: tablas ?? RESPALDO.LAAMBA.tablas };
    }
  }

  return salida;
}

/* Los horarios por categoría los carga el club, no la liga. */
function armarHorarios(filas) {
  const horarios = { ...RESPALDO.HORARIOS_FEFI };
  for (const f of filas) {
    if (f.tipo !== "horarios" || f.liga !== "fefi") continue;
    const horas = leerHorarios(f.datos?.detalle ?? "");
    if (Object.keys(horas).length) horarios[f.referencia] = { horas, entrada: null };
  }
  return horarios;
}

export default function App() {
  const { usuario, admin, entrar, registrarse, salir, guardarPreferencias } = useSesion();
  const { datos: remoto, desdeCache } = useLigas();
  const { productos, config, guardarProducto, guardarStock, guardarConfig } = useCatalogo({ admin });
  const pedidos = usePedidos({ admin, perfilId: usuario?.id });
  const contenidos = useContenidos();
  const carrito = useCarrito();

  const [tab, setTab] = useState("inicio");
  const [liga, setLiga] = useState("fefi");
  const [favsLocales, setFavsLocales] = useState([]);
  const [novedad, setNovedad] = useState(null);
  const [jugador, setJugador] = useState(null);
  const [verCarrito, setVerCarrito] = useState(false);

  const [cargasManuales, setCargasManuales] = useState([]);

  const recargarManual = React.useCallback(async () => {
    const { datos } = await manualApi.listar();
    if (datos) setCargasManuales(datos);
  }, []);
  useEffect(() => { recargarManual(); }, [recargarManual]);

  const ligasApp = React.useMemo(() => {
    const base = armarLigas(remoto);
    return { ...base, HORARIOS_FEFI: armarHorarios(cargasManuales) };
  }, [remoto, cargasManuales]);

  const manuales = cargasManuales.filter((m) => m.tipo === "partido");

  /* Con sesión los favoritos viajan con la cuenta; sin sesión, en el teléfono. */
  const favs = usuario ? usuario.favoritos ?? [] : favsLocales;
  const prefs = usuario?.notificaciones ?? {};

  useEffect(() => {
    if (usuario) return;
    leer("defe:favs").then((g) => g && setFavsLocales(g));
  }, [usuario]);

  const toggleFav = (id) => {
    const nuevos = favs.includes(id) ? favs.filter((x) => x !== id) : [...favs, id];
    if (usuario) guardarPreferencias({ favoritos: nuevos });
    else { setFavsLocales(nuevos); guardar("defe:favs", nuevos); }
  };

  const setPrefs = (nuevas) => guardarPreferencias({ notificaciones: nuevas });

  /* Carga manual: escribe en la base y refresca lo que ve todo el mundo. */
  const guardarHorarios = async (ligaId, fecha, detalle) => {
    await manualApi.guardarHorarios(ligaId, fecha, detalle);
    await recargarManual();
  };
  const guardarPartido = async (ligaId, partido) => {
    await manualApi.guardarPartido(ligaId, partido);
    await recargarManual();
  };
  const borrarManual = async (id) => {
    await manualApi.borrar(id);
    await recargarManual();
  };

  /* Si la base todavía no tiene catálogo, se muestra el de referencia. */
  const catalogo = productos.length ? productos : PRODUCTOS.map((p) => ({ ...p, visible: true, stock: null }));
  const tiendaCfg = config ?? TIENDA;

  const titulos = {
    inicio: "Defe", partidos: "Partidos", planteles: "Planteles", comunidad: "Comunidad",
    tienda: "Tienda del club", posiciones: "Posiciones", novedades: "Novedades",
    midefe: "Mi Defe", gestion: "Gestión",
  };
  const tabs = [
    ["inicio", Home, "Inicio"], ["partidos", CalendarDays, "Partidos"],
    ["planteles", Users, "Planteles"], ["comunidad", Newspaper, "Comunidad"],
    ["tienda", ShoppingBag, "Tienda"],
  ];

  return (
    <ContextoLigas.Provider value={ligasApp}>
    <div style={{ background: C.fondo, minHeight: "100vh", fontFamily: "Barlow, system-ui, sans-serif", color: C.tinta }}>
      <div className="mx-auto" style={{ maxWidth: 430, position: "relative" }}>
        <div style={{
          background: C.azul,
          backgroundImage: "repeating-linear-gradient(90deg, rgba(255,255,255,.06) 0 18px, transparent 18px 36px)",
          color: "#fff", position: "sticky", top: 0, zIndex: 40,
        }}>
          <div className="flex items-center gap-3 px-4 pb-3 pt-4">
            <Escudo size={30} />
            <div className="flex-1">
              <div style={{ fontFamily: "Anton, sans-serif", fontSize: 19, letterSpacing: 0.6 }}>{titulos[tab].toUpperCase()}</div>
              <div style={{ fontSize: 11, opacity: 0.75, marginTop: -2 }}>Defensores de Santos Lugares</div>
            </div>
            <button onClick={() => setTab("midefe")} className="flex items-center gap-1.5 rounded-full px-3 py-1.5"
              style={{ background: ["midefe", "gestion"].includes(tab) ? "rgba(255,255,255,.25)" : "rgba(255,255,255,.14)" }}
              aria-label="Mi Defe">
              <User size={15} />
              <span className="text-xs font-semibold">{usuario ? "Mi Defe" : "Ingresar"}</span>
            </button>
          </div>
          {desdeCache && (
            <div className="px-4 pb-2 text-xs" style={{ opacity: 0.8 }}>
              Sin conexión: estás viendo lo último que se descargó.
            </div>
          )}
        </div>

        <div className="pt-4" style={{ paddingBottom: 96 }}>
          {tab === "inicio" && <Inicio favs={favs} toggleFav={toggleFav} irA={setTab} abrirNovedad={setNovedad} horarios={{}} />}
          {tab === "partidos" && <Partidos favs={favs} toggleFav={toggleFav} liga={liga} setLiga={setLiga} manuales={manuales} horarios={{}} irA={setTab} />}
          {tab === "posiciones" && <Posiciones favs={favs} liga={liga} setLiga={setLiga} irA={setTab} />}
          {tab === "planteles" && <Planteles abrirJugador={setJugador} />}
          {tab === "comunidad" && <Comunidad abrirNovedad={setNovedad} abrirJugador={setJugador} />}
          {tab === "tienda" && <Tienda productos={catalogo} carrito={carrito.items} agregar={carrito.agregar} abrirCarrito={() => setVerCarrito(true)} />}
          {tab === "novedades" && <Novedades abrirNovedad={setNovedad} />}
          {tab === "midefe" && (
            <MiDefe usuario={usuario} prefs={prefs} setPrefs={setPrefs} favs={favs}
              entrar={entrar} registrarse={registrarse} salir={salir} irA={setTab} />
          )}
          {tab === "gestion" && (admin
            ? <Gestion productos={catalogo} guardarProducto={guardarProducto} guardarStock={guardarStock}
                pedidos={pedidos} tienda={tiendaCfg} guardarConfig={guardarConfig}
                horarios={ligasApp.HORARIOS_FEFI} guardarHorarios={guardarHorarios}
                manuales={manuales} guardarPartido={guardarPartido} borrarManual={borrarManual} />
            : <MiDefe usuario={usuario} prefs={prefs} setPrefs={setPrefs} favs={favs}
                entrar={entrar} registrarse={registrarse} salir={salir} irA={setTab} />)}
        </div>

        <div className="fixed bottom-0 left-0 right-0 mx-auto" style={{ maxWidth: 430, background: "#fff", borderTop: `1px solid ${C.linea}`, zIndex: 50 }}>
          <div className="grid grid-cols-5">
            {tabs.map(([k, Icono, label]) => {
              const activo = tab === k;
              return (
                <button key={k} onClick={() => setTab(k)} className="flex flex-col items-center gap-1 py-2.5">
                  <Icono size={21} style={{ color: activo ? C.azul : "#98A2B3" }} strokeWidth={activo ? 2.4 : 1.8} />
                  <span style={{ fontSize: 10.5, fontWeight: activo ? 700 : 500, color: activo ? C.azul : "#98A2B3" }}>{label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {novedad && <DetalleNovedad nota={novedad} cerrar={() => setNovedad(null)} />}
        {jugador && <FichaJugador jugador={jugador} cerrar={() => setJugador(null)} />}
        {verCarrito && carrito.items.length > 0 && (
          <Carrito carrito={carrito} cerrar={() => setVerCarrito(false)} crear={pedidos.crear} tienda={tiendaCfg} />
        )}
      </div>
    </div>
    </ContextoLigas.Provider>
  );
}
