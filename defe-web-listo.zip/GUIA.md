# Del prototipo al proyecto

`src/App.jsx` ya está cableado: sesión real, catálogo y pedidos contra la base,
ligas desde la sincronización y avisos push. El prototipo
(`defe-futbol-app.jsx`) queda como referencia visual, sin conexiones.

## Poner en marcha

```bash
cd proyecto
cp .env.example .env          # completar con los datos de Supabase
npm install
npm run dev
```

Antes de arrancar hacen falta dos iconos en `public/`: `icono-192.png` y
`icono-512.png`, con el escudo sobre fondo azul. Son los que usa el teléfono
cuando se instala la app.

## Qué reemplaza a qué

| En el prototipo | Pasa a ser |
|---|---|
| `ENCUENTROS_FEFI`, `TABLAS`, `SUPERLIGA`, `LAAMBA` | `useLigas()` |
| `PRODUCTOS`, estado `productos` | `useCatalogo()` |
| estado `carrito` y `agregar` | `useCarrito()` |
| estado `pedidos` y `registrarPedido` | `usePedidos()` |
| estado `sesion`, `prefs`, código `DEFE2026` | `useSesion()` |
| `PLANTELES`, `GOLEADORES`, `GALERIA`, `NOVEDADES` | `useContenidos()` |
| `TIENDA.whatsapp` | `config.whatsapp` de `useCatalogo()` |
| `horarios`, `manuales` | `manual` de `useLigas()` |

En la práctica, el cuerpo de `App()` queda así:

```jsx
import { useSesion, useLigas, useCatalogo, usePedidos, useContenidos, useCarrito } from "./hooks.js";

export default function App() {
  const { usuario, admin, entrar, salir, guardarPreferencias } = useSesion();
  const { datos: ligas, desdeCache, proximo } = useLigas();
  const { productos, config, guardarProducto, guardarStock } = useCatalogo({ admin });
  const { activos, historial, crear, cambiarEstado, cuenta } = usePedidos({ admin, perfilId: usuario?.id });
  const { planteles, goleadores, destacado, galeria, novedades } = useContenidos();
  const carrito = useCarrito();

  const favs = usuario?.favoritos ?? [];
  // …el resto de las pantallas, igual que en el prototipo
}
```

## Tres cosas que cambian de verdad

**El rol de dirigente.** Deja de ser el código `DEFE2026` escrito en la app y
pasa a ser una fila en la base. Se asigna con SQL sobre el email de la persona.
Nadie entra a Gestión escribiendo una palabra en un campo.

**El pedido.** `registrarPedido` guardaba en el teléfono; ahora `crear()` escribe
en Supabase, y el número y el descuento de stock los resuelve la base. El
dirigente ve el pedido aparecer sin refrescar.

**Los favoritos.** Con sesión iniciada viajan con la cuenta, así la misma familia
los tiene en el celular de la madre y en el del padre. Sin sesión siguen en el
teléfono, para que se pueda usar la app sin registrarse.

## Publicar

`npm run build` deja todo en `dist/`. Se puede publicar en el mismo GitHub Pages
del repo de datos, en Netlify o en Vercel. Si va en un subdirectorio, hay que
ajustar `base` en `vite.config.js`.

La app queda instalable: desde el navegador del celular, "Agregar a la pantalla
de inicio", y abre como cualquier otra app. El fixture y las tablas quedan
guardados, así que el sábado en la cancha abre aunque no haya señal.

## Notificaciones

Las preferencias de Mi Defe ya se guardan, pero mandar el aviso necesita una
pieza más: una Edge Function de Supabase que, cuando cambia un partido o entra
un resultado, le pegue a un servicio de push. Es el próximo paso natural y se
apoya en todo lo que ya está armado.

## Notificaciones

Las piezas: `notificaciones.sql` (tablas), `src/sw.js` (recibe el aviso),
`src/push.js` (pide permiso y registra el teléfono), la Edge Function `avisar`
(decide quién recibe y envía) y `avisos.mjs` (detecta qué cambió).

Puesta en marcha:

```bash
npx web-push generate-vapid-keys          # una sola vez
supabase functions deploy avisar --no-verify-jwt
supabase secrets set VAPID_PUBLICA=... VAPID_PRIVADA=... \
  VAPID_CONTACTO=mailto:club@defensoressl.com CLAVE_AVISOS=<una clave larga>
```

La pública también va al `.env` como `VITE_VAPID_PUBLICA`. En el repo de datos,
cargar dos secretos de GitHub: `AVISOS_URL` (la dirección de la función) y
`CLAVE_AVISOS` (la misma de arriba).

En la pantalla Mi Defe, el botón "Activar notificaciones del dispositivo" llama
a `activarAvisos(usuario?.id)`. Antes conviene consultar `estadoPush()`: si
devuelve `puede: false`, mostrar el motivo en vez de un botón que no funciona.

### Qué se manda y a quién

Cada sincronización compara con la anterior y arma los avisos: un resultado
nuevo dispara uno de tipo `resultados`, y un cambio de fecha, horario o cancha
dispara uno de tipo `cambios`. Los de `novedades` y `convocatorias` los manda un
dirigente al publicar.

El filtro respeta lo que cada familia eligió: si apagó un tipo de aviso no le
llega, y si tiene activado "solo mis categorías", solo recibe los avisos de las
categorías que sigue. Quien no tiene cuenta recibe únicamente los generales.

Cada aviso lleva una clave única, así que aunque la sincronización corra cuatro
veces por día, el mismo resultado se manda una sola vez.

### El caso de iPhone

En iPhone los avisos funcionan solo si la app está instalada en la pantalla de
inicio, y desde iOS 16.4. Desde Safari suelto no hay push y no hay forma de
evitarlo. `estadoPush()` lo detecta y devuelve el texto para explicárselo a la
persona. Conviene tenerlo en cuenta al difundir la app: en Android alcanza con
abrir el link, en iPhone hay que instalarla primero.
