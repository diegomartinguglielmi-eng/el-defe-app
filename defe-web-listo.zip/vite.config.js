import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

// base: si se publica en GitHub Pages dentro de un repo, poner "/<repo>/".
export default defineConfig({
  base: "/",
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      // Service worker propio: además de guardar la app para usarla sin señal,
      // recibe los avisos push aunque esté cerrada.
      strategies: "injectManifest",
      srcDir: "src",
      filename: "sw.js",
      manifest: {
        name: "El Defe",
        short_name: "Defe",
        description: "Baby fútbol y futsal del Club Defensores de Santos Lugares",
        theme_color: "#2E3192",
        background_color: "#F3F6FB",
        display: "standalone",
        orientation: "portrait",
        start_url: ".",
        icons: [
          { src: "icono-192.png", sizes: "192x192", type: "image/png" },
          { src: "icono-512.png", sizes: "512x512", type: "image/png" },
          { src: "icono-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
        ],
      },
      workbox: {
        // El fixture y las tablas quedan disponibles sin señal: en la cancha
        // casi nunca hay datos, y la app tiene que abrir igual.
        runtimeCaching: [
          {
            urlPattern: /datos\.json$/,
            handler: "StaleWhileRevalidate",
            options: { cacheName: "ligas" },
          },
          {
            urlPattern: /^https:\/\/fonts\.(googleapis|gstatic)\.com/,
            handler: "CacheFirst",
            options: { cacheName: "fuentes", expiration: { maxAgeSeconds: 60 * 60 * 24 * 365 } },
          },
        ],
      },
    }),
  ],
});
